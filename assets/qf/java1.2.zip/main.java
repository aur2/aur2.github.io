import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.BitmapFactory;
import java.io.FileOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.util.HashMap;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.ProgressBar;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import android.view.Gravity;
import android.content.Context;
import android.text.TextWatcher;
import android.text.Editable;
import com.tencent.mobileqq.music.api.IQQPlayer;
import com.tencent.mobileqq.music.SongInfo;
import com.tencent.mobileqq.qroute.QRoute;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import android.text.Html;
import android.view.MotionEvent;
import android.os.Handler;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.io.FileInputStream;
import com.tencent.qqnt.msg.api.IMsgService;
import com.tencent.qqnt.aio.adapter.api.IAIOPttApi;
import com.tencent.qqnt.msg.api.impl.MsgUtilApiImpl;
import com.tencent.qqnt.kernel.nativeinterface.MsgElement;
import com.tencent.qqnt.kernel.nativeinterface.PttElement;
import com.tencent.qqnt.kernelpublic.nativeinterface.Contact;
import java.net.HttpURLConnection;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
String[] qqkey={"点歌", "QQ点歌"};
String[] wykey={"网易点歌", "wy点歌"};
String[] kgkey={"酷狗点歌", "kg点歌"};
String configName="ql_kg";
String privateConfigName="sl_kg";
String modeConfigName="ql_ms";
String privateModeConfigName="sl_ms";
String listModeConfig="lb_kg";
String limitConfigName="qx_kg";
String historyConfig="ss_ls";
String historyExpKey="kg_exp";
boolean historyExpanded=false;
HashMap<String, SearchResult>search_results=new HashMap<>();
List<String>searchHistory=new ArrayList<>();
String myWeb_qq="aHR0cHM6Ly9hLmFhLmNhYi9xcS5tdXNpYw==";
String myWeb_wy="aHR0cHM6Ly9hLmFhLmNhYi93eS5tdXNpYw==";
String myWeb_kg="aHR0cHM6Ly9hcGlpLnhpYW55dXcuY24vYXBpL3YxL2t1Z291LW11c2ljLXNlYXJjaA==";
String kgSecret="sk-030b0f9335c6cef18c142ab359c03297";
String upd="aHR0cHM6Ly9hdXIyLmdpdGh1Yi5pby9hc3NldHMvcWYvdXBkLmpzb24=";
final Object lock=new Object();
String currentPlatform="qq";
LinearLayout rootLayout;
LinearLayout resultContainer;
AlertDialog mainSearchDialog;
LinearLayout historyLayout;
private String httpGet(String url) {
HttpURLConnection conn=null;
try {
URL u=new URL(url);
if (u.getProtocol().equalsIgnoreCase("https")) {
HttpsURLConnection httpsConn=(HttpsURLConnection) u.openConnection();
httpsConn.setHostnameVerifier((hostname, session)->true);
SSLContext ctx=SSLContext.getInstance("TLS");
ctx.init(null, new TrustManager[]{new X509TrustManager() {
public void checkClientTrusted(X509Certificate[] chain, String authType) {}
public void checkServerTrusted(X509Certificate[] chain, String authType) {}
public X509Certificate[] getAcceptedIssuers() {
return null;
}
}}, null);
httpsConn.setSSLSocketFactory(ctx.getSocketFactory());
conn=httpsConn;
}else{
conn=(HttpURLConnection) u.openConnection();
}
conn.setRequestMethod("GET");
conn.setConnectTimeout(15000);
conn.setReadTimeout(15000);
conn.setRequestProperty("User-Agent", "Mozilla/5.0");
if (conn.getResponseCode()!=200) {
return "";
}
BufferedReader br=new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
StringBuilder sb=new StringBuilder();
String line;
while ((line=br.readLine())!=null) {
sb.append(line);
}
br.close();
return sb.toString();
} catch (Exception e) {
return "";
}finally{
if (conn!=null) {
conn.disconnect();
}
}
}
private void httpDownload(String url, String path) throws IOException {
HttpURLConnection conn=null;
ReadableByteChannel rbc=null;
FileOutputStream fos=null;
try {
URL u=new URL(url);
if (u.getProtocol().equalsIgnoreCase("https")) {
HttpsURLConnection httpsConn=(HttpsURLConnection) u.openConnection();
httpsConn.setHostnameVerifier((hostname, session)->true);
SSLContext ctx=SSLContext.getInstance("TLS");
ctx.init(null, new TrustManager[]{new X509TrustManager() {
public void checkClientTrusted(X509Certificate[] chain, String authType) {}
public void checkServerTrusted(X509Certificate[] chain, String authType) {}
public X509Certificate[] getAcceptedIssuers() {
return null;
}
}}, null);
httpsConn.setSSLSocketFactory(ctx.getSocketFactory());
conn=httpsConn;
}else{
conn=(HttpURLConnection) u.openConnection();
}
conn.setRequestMethod("GET");
conn.setConnectTimeout(15000);
conn.setReadTimeout(15000);
conn.setRequestProperty("User-Agent", "Mozilla/5.0");
if (conn.getResponseCode()!=200) {
throw new IOException("download failed: "+conn.getResponseCode());
}
File file=new File(path);
if (!file.getParentFile().exists()) {
file.getParentFile().mkdirs();
}
rbc=Channels.newChannel(conn.getInputStream());
fos=new FileOutputStream(file);
fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
}finally{
try {
if (rbc!=null) {
rbc.close();
}
} catch (Exception e) {}
try {
if (fos!=null) {
fos.close();
}
} catch (Exception e) {}
if (conn!=null) {
conn.disconnect();
}
}
}
addItem("开/关点歌", "xiafeng2017");
addItem("搜索歌曲", "xiafeng2018");
private String sec(String str) {
try {
byte[] bytes=Base64.getDecoder().decode(str.trim());
return new String(bytes, StandardCharsets.UTF_8).trim();
} catch (Exception e) {}
return "";
}
private String cleanKw(String raw) {
if (raw==null) {
return "";
}
String temp=raw.replaceAll("[\\n\\r\\t]", " ");
temp=temp.replaceAll("\\s+", " ");
return temp.trim();
}
private void loadHistory() {
try {
String historyStr=getString(historyConfig, "", "");
searchHistory.clear();
if (historyStr!=null&&!historyStr.isEmpty()) {
String[] arr=historyStr.split("\\|");
for (String s:arr) {
if (s!=null&&!s.trim().isEmpty()) {
searchHistory.add(s.trim());
}
}
}
} catch (Exception e) {}
}
private void saveHistory() {
try {
StringBuilder sb=new StringBuilder();
for (int i=0; i<searchHistory.size(); i++) {
if (i>0) {
sb.append("|");
}
sb.append(searchHistory.get(i));
}
putString(historyConfig, "", sb.toString());
} catch (Exception e) {}
}
private void addToHistory(String keyword) {
if (keyword==null||keyword.trim().isEmpty()) {
return;
}
String k=keyword.trim();
searchHistory.remove(k);
searchHistory.add(0, k);
saveHistory();
}
private TextView createTagTv(Activity activity, String text) {
LinearLayout.LayoutParams tagLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
tagLp.setMargins(0, 0, 12, 0);
GradientDrawable tagBg=new GradientDrawable();
tagBg.setColor(Color.parseColor("#ffffff"));
tagBg.setCornerRadius(16);
tagBg.setStroke(2, Color.parseColor("#aaBEE7"));
TextView tv=new TextView(activity);
tv.setText(text);
tv.setTextSize(11);
tv.setTextColor(Color.parseColor("#123456"));
tv.setPadding(12, 6, 12, 6);
tv.setBackground(tagBg);
tv.setLayoutParams(tagLp);
tv.setMinWidth(120);
return tv;
}
private void rebuildHistoryUi(Activity activity, LinearLayout parentLayout, final EditText editText, final String group, final String uin, final boolean isGroup) {
if (searchHistory==null||searchHistory.isEmpty()) return;
historyLayout=new LinearLayout(activity);
historyLayout.setOrientation(LinearLayout.VERTICAL);
historyLayout.setPadding(0, 16, 0, 8);
LinearLayout historyHead=new LinearLayout(activity);
historyHead.setOrientation(LinearLayout.HORIZONTAL);
historyHead.setGravity(Gravity.CENTER_VERTICAL);
TextView historyTitle=new TextView(activity);
historyTitle.setText("搜索历史");
historyTitle.setTextSize(13);
historyTitle.setTextColor(Color.parseColor("#666666"));
LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
historyTitle.setLayoutParams(titleParams);
Button clearBtn=new Button(activity);
clearBtn.setText(" 🗑️ ");
clearBtn.setTextSize(11);
clearBtn.setBackgroundColor(Color.TRANSPARENT);
clearBtn.setTextColor(Color.parseColor("#666666"));
clearBtn.setPadding(8, 2, 8, 2);
clearBtn.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
searchHistory.clear();
saveHistory();
historyExpanded=false;
putBoolean(historyExpKey, "", false);
parentLayout.removeView(historyLayout);
toast("已清空历史");
}
});
Button toggleExpandBtn=new Button(activity);
toggleExpandBtn.setText(historyExpanded ? "︿" : "﹀");
toggleExpandBtn.setTextSize(10);
toggleExpandBtn.setBackgroundColor(Color.TRANSPARENT);
toggleExpandBtn.setTextColor(Color.parseColor("#666666"));
toggleExpandBtn.setPadding(12, 4, 12, 4);
toggleExpandBtn.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
historyExpanded=!historyExpanded;
putBoolean(historyExpKey, "", historyExpanded);
parentLayout.removeView(historyLayout);
rebuildHistoryUi(activity, parentLayout, editText, group, uin, isGroup);
}
});
historyHead.addView(historyTitle);
historyHead.addView(clearBtn);
historyHead.addView(toggleExpandBtn);
historyLayout.addView(historyHead);
LinearLayout flowContainer=new LinearLayout(activity);
flowContainer.setOrientation(LinearLayout.VERTICAL);
flowContainer.setPadding(0, 8, 0, 0);
LinearLayout currentRow=new LinearLayout(activity);
currentRow.setOrientation(LinearLayout.HORIZONTAL);
currentRow.setPadding(0, 4, 0, 4);
flowContainer.addView(currentRow);
final int maxRowWidth=860;
int usedW=0;
for (int i=0; i<searchHistory.size(); i++) {
String kw=searchHistory.get(i);
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.parseColor("#EEEEEE"));
bg.setCornerRadius(20);
final TextView tv=new TextView(activity);
tv.setText(kw);
tv.setTextSize(13);
tv.setTextColor(Color.parseColor("#333333"));
tv.setBackground(bg);
tv.setPadding(14, 6, 14, 6);
LinearLayout.LayoutParams tvLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
tvLp.setMargins(6, 4, 6, 4);
tv.setLayoutParams(tvLp);
tv.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
String key=((TextView) v).getText().toString();
InputMethodManager imm=(InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
editText.setText(key);
editText.setSelection(key.length());
if (historyLayout!=null) {
historyLayout.setVisibility(View.GONE);
}
String clean=cleanKw(key);
addToHistory(clean);
searchAndShowList(key, group, uin, isGroup, false);
}
});
tv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
int tagFull=tv.getMeasuredWidth()+tvLp.leftMargin+tvLp.rightMargin;
if (!historyExpanded) {
if (usedW+tagFull>maxRowWidth) break;
currentRow.addView(tv);
usedW+=tagFull;
}else{
if (usedW+tagFull>maxRowWidth) {
currentRow=new LinearLayout(activity);
currentRow.setOrientation(LinearLayout.HORIZONTAL);
currentRow.setPadding(0, 4, 0, 4);
flowContainer.addView(currentRow);
usedW=0;
}
currentRow.addView(tv);
usedW+=tagFull;
}
}
historyLayout.addView(flowContainer);
parentLayout.addView(historyLayout);
}
public void xiafeng2017(int chatType, String peerUin, String name) {
if (chatType==2) {
boolean now=getBoolean(configName, peerUin, false);
putBoolean(configName, peerUin, !now);
toast(!now?"已开启本群点歌":"已关闭本群点歌");
}else{
boolean now=getBoolean(privateConfigName, peerUin, false);
putBoolean(privateConfigName, peerUin, !now);
toast(!now?"已开启私聊点歌":"已关闭私聊点歌");
}
}
public void xiafeng2018(final int chatType, final String peerUin, final String name) {
loadHistory();
historyExpanded=getBoolean(historyExpKey, "", false);
final boolean isGroup=(chatType==2);
final String group=isGroup?peerUin:"";
final String uin=isGroup?"":peerUin;
final Activity activity=getNowActivity();
activity.runOnUiThread(new Runnable() {
public void run() {
AlertDialog.Builder builder=new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
builder.setTitle("搜索歌曲𝒥𝒶𝓋𝒶");
LinearLayout outerRoot=new LinearLayout(activity);
outerRoot.setOrientation(LinearLayout.VERTICAL);
outerRoot.setPadding(40, 40, 40, 40);
LinearLayout fixTopLayout=new LinearLayout(activity);
fixTopLayout.setOrientation(LinearLayout.VERTICAL);
LinearLayout btnLayout=new LinearLayout(activity);
btnLayout.setOrientation(LinearLayout.HORIZONTAL);
btnLayout.setGravity(Gravity.END);
btnLayout.setPadding(0, 0, 0, 12);
final TextView tvPlatform=createTagTv(activity, "");
Runnable refreshPlat=new Runnable() {
public void run() {
String tip;
if("wy".equals(currentPlatform)){
tip="网易";
}else if("kg".equals(currentPlatform)){
tip="酷狗";
}else{
tip="QQ";
}
tvPlatform.setText("平台："+tip);
}
};
refreshPlat.run();
tvPlatform.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
if ("qq".equals(currentPlatform)){
currentPlatform="wy";
}else if("wy".equals(currentPlatform)){
currentPlatform="kg";
}else{
currentPlatform="qq";
}
refreshPlat.run();
String tip;
if("wy".equals(currentPlatform)){
tip="网易";
}else if("kg".equals(currentPlatform)){
tip="酷狗";
}else{
tip="QQ";
}
toast("已切换："+tip+"音乐");
}
});
final String modeKey=isGroup?modeConfigName:privateModeConfigName;
final String modeTargetId=isGroup?group:uin;
final TextView tvMode=createTagTv(activity, "");
Runnable refreshMode=new Runnable() {
public void run() {
String val=getString(modeKey, modeTargetId, "card");
String tip="card".equals(val)?"卡片":"voice".equals(val)?"语音":"播放";
tvMode.setText("模式："+tip);
}
};
refreshMode.run();
tvMode.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
String now=getString(modeKey, modeTargetId, "card");
String newMode, tip;
if ("card".equals(now)) {
newMode="voice";
tip="语音";
} else if ("voice".equals(now)) {
newMode="qq_player";
tip="播放";
}else{
newMode="card";
tip="卡片";
}
putString(modeKey, modeTargetId, newMode);
refreshMode.run();
toast("已切换："+tip);
}
});
final TextView tvList=createTagTv(activity, "");
Runnable refreshList=new Runnable() {
public void run() {
boolean state=getBoolean(listModeConfig, group, false);
tvList.setText("列表："+(state?"开":"关"));
}
};
refreshList.run();
tvList.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
boolean next=!getBoolean(listModeConfig, group, false);
putBoolean(listModeConfig, group, next);
refreshList.run();
toast("已"+(next?"开启":"关闭")+"列表模式");
}
});
final TextView tvLimit=createTagTv(activity, "");
Runnable refreshLimit=new Runnable() {
public void run() {
boolean state=getBoolean(limitConfigName, group, false);
tvLimit.setText("限制："+(state?"开":"关"));
}
};
refreshLimit.run();
tvLimit.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
boolean next=!getBoolean(limitConfigName, group, false);
putBoolean(limitConfigName, group, next);
refreshLimit.run();
toast("已"+(next?"开启":"关闭")+"本群限制");
}
});
btnLayout.addView(tvPlatform);
btnLayout.addView(tvMode);
btnLayout.addView(tvList);
btnLayout.addView(tvLimit);
fixTopLayout.addView(btnLayout);
LinearLayout searchRow=new LinearLayout(activity);
searchRow.setOrientation(LinearLayout.HORIZONTAL);
searchRow.setPadding(0, 8, 0, 8);
final EditText editText=createEditText(activity, "");
editText.setHint("请输入歌曲名...");
editText.setHintTextColor(Color.parseColor("#999999"));
editText.setSingleLine(true);
editText.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
editText.addTextChangedListener(new TextWatcher() {
public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
public void onTextChanged(CharSequence s, int start, int before, int count) {
String content=s.toString().trim();
if (content.isEmpty()) {
resultContainer.removeAllViews();
if (historyLayout!=null) {
historyLayout.setVisibility(View.VISIBLE);
}
}
}
public void afterTextChanged(Editable s) {}
});
LinearLayout.LayoutParams etLp=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
editText.setLayoutParams(etLp);
Button searchBtn=new Button(activity);
searchBtn.setText("搜索");
GradientDrawable btnBg=new GradientDrawable();
btnBg.setColor(Color.parseColor("#aaBEE7"));
btnBg.setCornerRadius(30);
searchBtn.setBackground(btnBg);
searchBtn.setTextColor(Color.parseColor("#123456"));
LinearLayout.LayoutParams btnLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
btnLp.setMargins(12, 0, 0, 0);
searchBtn.setLayoutParams(btnLp);
final Runnable searchRunnable=new Runnable() {
public void run() {
String key=editText.getText().toString();
String clean=cleanKw(key);
if (clean.isEmpty()) {
resultContainer.removeAllViews();
toast("输入为空");
return;
}
if (historyLayout!=null) {
historyLayout.setVisibility(View.GONE);
}
addToHistory(clean);
searchAndShowList(key, group, uin, isGroup, false);
}
};
View.OnClickListener searchClick=new View.OnClickListener() {
public void onClick(View v) {
InputMethodManager imm=(InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
searchRunnable.run();
}
};
searchBtn.setOnClickListener(searchClick);
editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
if (actionId==EditorInfo.IME_ACTION_SEARCH) {
searchClick.onClick(v);
return true;
}
return false;
}
});
searchRow.addView(editText);
searchRow.addView(searchBtn);
fixTopLayout.addView(searchRow);
if (searchHistory!=null&&!searchHistory.isEmpty()) {
rebuildHistoryUi(activity, fixTopLayout, editText, group, uin, isGroup);
}
ScrollView scrollView=new ScrollView(activity);
scrollView.setVerticalScrollBarEnabled(false);
scrollView.setHorizontalScrollBarEnabled(false);
resultContainer=new LinearLayout(activity);
resultContainer.setOrientation(LinearLayout.VERTICAL);
resultContainer.setPadding(0, 20, 0, 0);
scrollView.addView(resultContainer);
LinearLayout.LayoutParams fixLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
LinearLayout.LayoutParams scrollLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
outerRoot.addView(fixTopLayout, fixLp);
outerRoot.addView(scrollView, scrollLp);
rootLayout=outerRoot;
builder.setView(outerRoot);
builder.setPositiveButton("", null);
final AlertDialog dialog=builder.create();
mainSearchDialog=dialog;
UI(dialog);
dialog.show();
dialog.getWindow().setLayout(980, -2);
dialog.getButton(DialogInterface.BUTTON_POSITIVE).setVisibility(View.GONE);
editText.requestFocus();
new android.os.Handler().postDelayed(new Runnable() {
public void run() {
((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(editText, 2);
}
}, 200);
}
});
}
public void searchAndShowList(final String key, final String group, final String uin, final boolean isGroup, final boolean closeDialog) {
new Thread(new Runnable() {
public void run() {
try {
String clean=cleanKw(key);
if (clean.isEmpty()) {
throw new Exception();
}
String encoded=URLEncoder.encode(clean, "UTF-8");
String url="";
if ("qq".equals(currentPlatform)) {
url=sec(myWeb_qq)+"?msg="+encoded+"&num=20";
} else if ("wy".equals(currentPlatform)) {
url=sec(myWeb_wy)+"?msg="+encoded+"&num=20";
} else if("kg".equals(currentPlatform)){
url=sec(myWeb_kg)+"?key="+kgSecret+"&msg="+encoded+"&num=20";
}
String resp=httpGet(url);
if (resp==null||resp.trim().isEmpty()) {
throw new Exception();
}
JSONObject json=new JSONObject(resp);
int code=json.getInt("code");
JSONArray data=json.getJSONArray("data");
if (code!=200||data.length()==0) {
throw new Exception();
}
final List<String>names=new ArrayList<>();
final List<Object>ids=new ArrayList<>();
for (int i=0; i<data.length(); i++) {
JSONObject item=data.getJSONObject(i);
String title, author;
if ("qq".equals(currentPlatform)) {
title=item.optString("song", "未知歌曲");
author=item.optString("singer", "未知歌手");
}else if ("wy".equals(currentPlatform)) {
title=item.optString("title", item.optString("song", "未知歌曲"));
author=item.optString("author", item.optString("singer", "未知歌手"));
}else if("kg".equals(currentPlatform)){
title=item.optString("title", "未知歌曲");
author=item.optString("author", "未知歌手");
}
names.add((i+1)+". "+title+"-"+author);
ids.add(i+1);
}
final Activity act=getNowActivity();
if (act==null) {
return;
}
act.runOnUiThread(new Runnable() {
public void run() {
resultContainer.removeAllViews();
final String clickMode=isGroup?getString(modeConfigName, group, "card"):getString(privateModeConfigName, uin, "card");
for (int i=0; i<names.size(); i++) {
String itemText=names.get(i);
final Object idObj=ids.get(i);
LinearLayout itemLayout=new LinearLayout(act);
itemLayout.setOrientation(LinearLayout.HORIZONTAL);
itemLayout.setGravity(Gravity.CENTER_VERTICAL);
itemLayout.setPadding(15, 12, 15, 12);
GradientDrawable itemBg=new GradientDrawable();
itemBg.setColor(Color.parseColor("#f7f7f7"));
itemBg.setCornerRadius(12);
itemBg.setStroke(1, Color.parseColor("#dddddd"));
itemLayout.setBackground(itemBg);
TextView itemTv=new TextView(act);
itemTv.setText(itemText);
itemTv.setTextSize(14);
itemTv.setTextColor(Color.parseColor("#333333"));
LinearLayout.LayoutParams tvLp=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
itemTv.setLayoutParams(tvLp);
ProgressBar itemProgress=new ProgressBar(act);
itemProgress.setVisibility(View.GONE);
LinearLayout.LayoutParams proLp=new LinearLayout.LayoutParams(35, 35);
proLp.setMargins(10, 0, 0, 0);
itemProgress.setLayoutParams(proLp);
itemLayout.addView(itemTv);
itemLayout.addView(itemProgress);
LinearLayout.LayoutParams itemLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
itemLp.setMargins(0, 6, 0, 0);
itemLayout.setLayoutParams(itemLp);
itemLayout.setTag(new Object[]{idObj, itemProgress});
itemLayout.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
Object[] tagArr=(Object[]) v.getTag();
Object realId=tagArr[0];
ProgressBar proBar=(ProgressBar) tagArr[1];
act.runOnUiThread(new Runnable() {
public void run() {
proBar.setVisibility(View.VISIBLE);
}
});
if ("qq".equals(currentPlatform)) {
getMusicByIndex_qq(key, (Integer) realId, group, uin, isGroup, proBar);
} else if ("wy".equals(currentPlatform)) {
getMusicByIndex_wy(key, (Integer) realId, group, uin, isGroup, proBar);
} else if("kg".equals(currentPlatform)){
getMusicByIndex_kg(key, (Integer) realId, group, uin, isGroup, proBar);
}
}
});
resultContainer.addView(itemLayout);
}
if (closeDialog&&mainSearchDialog!=null) {
mainSearchDialog.dismiss();
}
}
});
} catch (Exception e) {
Activity act=getNowActivity();
if (act!=null) {
act.runOnUiThread(new Runnable() {
public void run() {
toast("获取失败,请稍后重试。");
}
});
}
}
}
}).start();
}
public void getMusicByIndex_qq(final String songName, final int index, final String group, final String uin, final boolean isGroup, ProgressBar bar) {
new Thread(new Runnable() {
public void run() {
try {
String clean=cleanKw(songName);
if (clean.isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(clean, "UTF-8");
String url=sec(myWeb_qq)+"?msg="+encoded+"&num=20&n="+index;
String response=httpGet(url);
if (response==null||response.trim().isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject json=new JSONObject(response);
if (json.getInt("code")!=0) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject data=json.getJSONObject("data");
String title=data.optString("song", "未知歌曲");
String singer=data.optString("singer", "未知歌手");
String coverUrl=data.optString("cover");
String musicUrl=data.optString("music");
if (title.isEmpty()||musicUrl.isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, "qq", bar);
} catch (Exception e) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
public void getMusicByIndex_wy(final String songName, final int index, final String group, final String uin, final boolean isGroup, ProgressBar bar) {
new Thread(new Runnable() {
public void run() {
try {
String clean=cleanKw(songName);
if (clean.isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(clean, "UTF-8");
String url=sec(myWeb_wy)+"?msg="+encoded+"&num=20&n="+index;
String response=httpGet(url);
if (response==null||response.trim().isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject json=new JSONObject(response);
JSONObject data=json.getJSONObject("data");
String title=data.optString("song", "未知歌曲");
String singer=data.optString("singer");
String coverUrl=data.optString("cover");
String musicUrl=data.optString("music");
if (title.isEmpty()||musicUrl.isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
}
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, "163", bar);
} catch (Exception e) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
public void getMusicByIndex_kg(final String songName, final int index, final String group, final String uin, final boolean isGroup, ProgressBar bar) {
new Thread(new Runnable() {
public void run() {
try {
String clean=cleanKw(songName);
if (clean.isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(clean, "UTF-8");
String url=sec(myWeb_kg)+"?key="+kgSecret+"&msg="+encoded+"&n="+index;
String response=httpGet(url);
if (response==null||response.trim().isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject json=new JSONObject(response);
if (json.getInt("code")!=200) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject data=json.getJSONObject("data");
String title=data.optString("title", "未知歌曲");
String singer=data.optString("author", "未知歌手");
String coverUrl=data.optString("cover");
String musicUrl=data.optString("url");
if (title.isEmpty()||musicUrl.isEmpty()) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
return;
}
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, "kugou", bar);
} catch (Exception e) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
if (bar!=null) bar.setVisibility(View.GONE);
}
});
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
private EditText createEditText(Activity activity, String defaultValue) {
EditText editText=new EditText(activity);
editText.setText(defaultValue==null?"":defaultValue);
editText.setTextSize(14);
editText.setMinHeight(120);
editText.setPadding(40, 24, 40, 24);
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.parseColor("#ffffff"));
bg.setCornerRadius(30);
bg.setStroke(2, Color.parseColor("#aaBEE7"));
editText.setBackground(bg);
LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
params.bottomMargin=16;
editText.setLayoutParams(params);
return editText;
}
public void UI(AlertDialog dialog) {
GradientDrawable gradientDrawable=new GradientDrawable();
gradientDrawable.setColor(Color.parseColor("#aaBEE7"));
gradientDrawable.setCornerRadius(50);
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
dialog.getWindow().setDimAmount(0.2f);
}else{
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
}
WindowManager.LayoutParams params=dialog.getWindow().getAttributes();
params.alpha=0.9f;
dialog.getWindow().setAttributes(params);
dialog.setOnShowListener(new DialogInterface.OnShowListener() {
public void onShow(DialogInterface dialogInterface) {
setBtnColor(dialog, DialogInterface.BUTTON_POSITIVE);
setBtnColor(dialog, DialogInterface.BUTTON_NEGATIVE);
}
});
}
private void setBtnColor(AlertDialog dialog, int btn) {
if (dialog.getButton(btn)!=null) {
dialog.getButton(btn).setTextColor(Color.parseColor("#123456"));
}
}
public Bitmap downloadCover(String coverUrl) {
try {
String tempPath=pluginPath+"/temp_cover.jpg";
httpDownload(coverUrl, tempPath);
Bitmap bmp=BitmapFactory.decodeFile(tempPath);
new File(tempPath).delete();
return bmp;
} catch (Exception e) {}
return null;
}
public void sendTipMsg(String target, boolean isGroup, String tip) {
int chatType=isGroup?2:1;
sendMsg(target, tip, chatType);
}
public boolean sendMusicCard(String targetUin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt) {
try {
String encodedUrl=URLEncoder.encode(musicUrl, "UTF-8");
String encodedCover=URLEncoder.encode(coverUrl, "UTF-8");
String encodedTitle=URLEncoder.encode(title, "UTF-8");
String encodedSinger=URLEncoder.encode(singer, "UTF-8");
String apiUrl="https://oiapi.net/API/QQMusicJSONArk?format="+fmt+"&url="+encodedUrl+"&song="+encodedTitle+"&singer="+encodedSinger+"&cover="+encodedCover+"&jump="+encodedUrl;
String arkResponse=httpGet(apiUrl);
if (arkResponse==null||arkResponse.trim().isEmpty()) {
return false;
}
JSONObject arkJson=new JSONObject(arkResponse);
if (arkJson.getInt("code")==1) {
String cardJson=arkJson.getString("message");
int chatType=isGroup?2:1;
sendCard(targetUin, cardJson, chatType);
return true;
}
} catch (Exception e) {}
return false;
}
public void generateSearchListImage(JSONArray data, String coverUrl, String target, boolean isGroup, Object msg) {
new Thread(new Runnable() {
public void run() {
synchronized (lock) {
try {
int displayCount=Math.min(data.length(), 15);
int itemHeight=70;
int topPadding=60;
int leftPadding=60;
int width=1080;
int height=topPadding+60+displayCount*itemHeight+80+60;
Bitmap bitmap=Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
Canvas canvas=new Canvas(bitmap);
canvas.drawColor(Color.parseColor("#FAFBFC"));
Bitmap coverBmp=downloadCover(coverUrl);
if (coverBmp!=null) {
Paint coverPaint=new Paint();
coverPaint.setAlpha(70);
Bitmap scaledCover=Bitmap.createScaledBitmap(coverBmp, width, height, true);
canvas.drawBitmap(scaledCover, 0, 0, coverPaint);
scaledCover.recycle();
coverBmp.recycle();
}
Paint titlePaint=new Paint();
titlePaint.setColor(Color.parseColor("#222222"));
titlePaint.setTextSize(48);
titlePaint.setAntiAlias(true);
titlePaint.setFakeBoldText(true);
float y=topPadding;
canvas.drawText("搜索结果:", leftPadding, y, titlePaint);
y+=itemHeight-10;
y+=25;
Paint textPaint=new Paint();
textPaint.setColor(Color.parseColor("#333333"));
textPaint.setTextSize(40);
textPaint.setAntiAlias(true);
for (int i=0; i<displayCount; i++) {
JSONObject item=data.getJSONObject(i);
String title, singer;
if ("qq".equals(currentPlatform)) {
title=item.optString("song", "未知");
singer=item.optString("singer", "未知");
}else if ("wy".equals(currentPlatform)) {
title=item.optString("title", item.optString("song", "未知"));
singer=item.optString("author", item.optString("singer", "未知"));
}else if("kg".equals(currentPlatform)){
title=item.optString("title", "未知");
singer=item.optString("author", "未知");
}
String line=(i+1)+"、"+title+"-"+singer;
canvas.drawText(line, leftPadding, y, textPaint);
y+=itemHeight;
}
Paint tipPaint=new Paint();
tipPaint.setColor(Color.parseColor("#666666"));
tipPaint.setTextSize(36);
tipPaint.setAntiAlias(true);
canvas.drawText("请发送序号选择（1～15）,120秒内有效。", leftPadding, height-60, tipPaint);
String path=pluginPath+"/search_list.png";
FileOutputStream fos=new FileOutputStream(path);
bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
fos.close();
bitmap.recycle();
String pic="[pic="+path+"]";
int chatType=isGroup?2:1;
long replyMsgId=0;
try {
replyMsgId=(Long) msg.getClass().getField("msgId").get(msg);
} catch (Exception e) {}
if (replyMsgId!=0&&isGroup) {
sendReplyMsg(target, replyMsgId, pic, chatType);
}else{
sendMsg(target, pic, chatType);
}
new File(path).delete();
} catch (Exception e) {}
}
}
}).start();
}
public void processMusicSelection(String text, String uin, String group, boolean isGroup) {
try {
if (!text.matches("[0-9]+")||text.length()>2) {
return;
}
int index=Integer.parseInt(text);
String key=group+"_"+uin;
if (!search_results.containsKey(key)) {
return;
}
SearchResult result=search_results.get(key);
if (result==null||result.data==null||index>15) {
return;
}
if (System.currentTimeMillis()-result.timestamp>120*1000) {
search_results.remove(key);
return;
}
if ("qq".equals(result.type)) {
getMusicByIndex_qq(result.searchKey, index, group, uin, isGroup, null);
} else if ("wy".equals(result.type)) {
JSONObject item=result.data.getJSONObject(index-1);
String songName=item.optString("song");
getMusicByIndex_wy(songName, index, group, uin, isGroup, null);
}else if("kg".equals(result.type)){
JSONObject item=result.data.getJSONObject(index-1);
String songName=item.optString("title");
getMusicByIndex_kg(songName, index, group, uin, isGroup, null);
}
} catch (Exception e) {}
}
public void showErrorTip(String targetGroup, String targetUin, boolean isGroup) {
sendTipMsg(isGroup?targetGroup:targetUin, isGroup, "获取失败,请稍后重试。");
}
public void playMusicByQQ(String song, String singer, String link, String musicUrl, String cover, String type) {
try {
Context context=getNowActivity();
SongInfo info=new SongInfo(1L, cover, musicUrl);
info.e=singer;
info.i=song;
info.m=link;
QRoute.api(IQQPlayer.class).startPlayMusic(context, type, new SongInfo[]{info});
} catch (Exception e) {}
}
public void sendMusicResult(String group, String uin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt, ProgressBar bar) {
String mode=isGroup?getString(modeConfigName, group, "card"):getString(privateModeConfigName, uin, "card");
boolean showTip=false;
if ("card".equals(mode)) {
boolean ok=sendMusicCard(isGroup?group:uin, title, singer, coverUrl, musicUrl, isGroup, fmt);
if (ok) {
showTip=true;
if (mainSearchDialog!=null) mainSearchDialog.dismiss();
}
} else if ("voice".equals(mode)) {
try {
Context appContext=getNowActivity().getApplicationContext();
File tempAudioFile=new File(appContext.getCacheDir(), System.currentTimeMillis()+".mp3");
String path=tempAudioFile.getAbsolutePath();
httpDownload(musicUrl, path);
int chatType=isGroup?2:1;
String targetUin=isGroup?group:uin;
if(chatType==2){
com.tencent.qqnt.kernelpublic.nativeinterface.Contact contact=new com.tencent.qqnt.kernelpublic.nativeinterface.Contact(chatType,targetUin,"");
ArrayList elementList=new ArrayList();
com.tencent.qqnt.msg.api.impl.MsgUtilApiImpl m=new com.tencent.qqnt.msg.api.impl.MsgUtilApiImpl();
com.tencent.qqnt.kernel.nativeinterface.MsgElement msgElement=m.createPttElement(path,1000);
com.tencent.qqnt.kernel.nativeinterface.PttElement pttElement=msgElement.getPttElement();
List byList=new ArrayList();
byte[] b={28,26,43,29,31,61,34,49,51,56,52,74,41,62,66,46,25,57,51,70,33,45,39,27,68,58,46,59,63};
for(int i=0;i<b.length;i++)byList.add(b[i]);
pttElement.waveAmplitudes=byList;
elementList.add(msgElement);
((com.tencent.qqnt.msg.api.IMsgService)QRoute.api(com.tencent.qqnt.msg.api.IMsgService.class)).sendMsg(contact,elementList,null);
}else{
sendPtt(targetUin, path, chatType);
}
if (tempAudioFile.exists()) tempAudioFile.delete();
showTip=true;
if (mainSearchDialog!=null) mainSearchDialog.dismiss();
} catch (Exception e) {}
} else if ("qq_player".equals(mode)) {
showTip=true;
String qType;
if("163".equals(fmt)){
qType="wy";
}else if("kugou".equals(fmt)){
qType="wy";
}else{
qType="qmp_play";
}
playMusicByQQ(title, singer, musicUrl, musicUrl, coverUrl, qType);
}
if (showTip) toast("已发送");
if (bar!=null) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
bar.setVisibility(View.GONE);
}
});
}
}
public void sendMusicResult(String group, String uin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt) {
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, fmt, null);
}
public void searchMusicCommon(String songName, String group, String uin, boolean isGroup, Object msg) {
new Thread(new Runnable() {
public void run() {
try {
String clean=cleanKw(songName);
if (clean.isEmpty()) {
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(clean, "UTF-8");
String url="", type="";
if ("qq".equals(currentPlatform)) {
url=sec(myWeb_qq)+"?msg="+encoded+"&num=15";
type="qq";
} else if ("wy".equals(currentPlatform)) {
url=sec(myWeb_wy)+"?msg="+encoded+"&num=15";
type="wy";
} else if("kg".equals(currentPlatform)){
url=sec(myWeb_kg)+"?key="+kgSecret+"&msg="+encoded+"&num=15";
type="kg";
}
String resp=httpGet(url);
JSONObject json=new JSONObject(resp);
if (json.getInt("code")!=200) {
showErrorTip(group, uin, isGroup);
return;
}
JSONArray data=json.getJSONArray("data");
String key=group+"_"+uin;
boolean listEnabled=getBoolean(listModeConfig, group, false);
if (listEnabled) {
SearchResult r=new SearchResult();
r.type=type;
r.data=data;
r.timestamp=System.currentTimeMillis();
r.searchKey=clean;
search_results.put(key, r);
String cover="";
if (data.length()>0) {
if ("qq".equals(type)) {
cover=data.getJSONObject(0).optString("cover");
}else if ("wy".equals(type)) {
cover=data.getJSONObject(0).optString("cover", data.getJSONObject(0).optString("picture"));
}else if("kg".equals(type)){
cover=data.getJSONObject(0).optString("cover");
}
}
generateSearchListImage(data, cover, isGroup?group:uin, isGroup, msg);
}else{
if ("qq".equals(currentPlatform)) {
getMusicByIndex_qq(songName, 1, group, uin, isGroup, null);
} else if ("wy".equals(currentPlatform)) {
getMusicByIndex_wy(songName, 1, group, uin, isGroup, null);
}else if("kg".equals(currentPlatform)){
getMusicByIndex_kg(songName, 1, group, uin, isGroup, null);
}
}
} catch (Exception e) {
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
public void onMsg(Object msg) {
try {
String text=(String) msg.getClass().getField("msg").get(msg);
String senderUin=(String) msg.getClass().getField("userUin").get(msg);
int type=(Integer) msg.getClass().getField("type").get(msg);
boolean isGroup=(type==2);
String peerUin=(String) msg.getClass().getField("peerUin").get(msg);
long msgId=(Long) msg.getClass().getField("msgId").get(msg);
boolean isSend=senderUin.equals(myUin);
String group=isGroup?peerUin:"";
String uin=isGroup?senderUin:peerUin;
if (isGroup&&getBoolean(limitConfigName, group, false)&&!isSend) {
return;
}
boolean listEnabled=getBoolean(listModeConfig, group, false);
if (listEnabled&&text.matches("[0-9]+")&&text.length()<=2) {
if (isGroup) {
if (getBoolean(configName, group, false)) {
processMusicSelection(text, senderUin, group, true);
}
}else{
if (getBoolean(privateConfigName, peerUin, false)) {
processMusicSelection(text, peerUin, "", false);
}
}
return;
}
boolean qqTrigger=false, wyTrigger=false, kgTrigger=false;
String trigger=null;
for (String k:qqkey) {
if (text.startsWith(k)) {
qqTrigger=true;
trigger=k;
break;
}
}
if (!qqTrigger) {
for (String k:wykey) {
if (text.startsWith(k)) {
wyTrigger=true;
trigger=k;
break;
}
}
}
if(!qqTrigger&&!wyTrigger){
for(String k:kgkey){
if(text.startsWith(k)){
kgTrigger=true;
trigger=k;
break;
}
}
}
if (trigger!=null) {
if (isGroup&&!getBoolean(configName, group, false)) {
return;
}
if (!isGroup&&!getBoolean(privateConfigName, peerUin, false)) {
return;
}
String rawKw=text.substring(trigger.length());
String kw=cleanKw(rawKw);
if (kw.isEmpty()) {
sendTipMsg(isGroup?group:peerUin, isGroup, "请输入歌名");
return;
}
if (qqTrigger) currentPlatform="qq";
if (wyTrigger) currentPlatform="wy";
if(kgTrigger) currentPlatform="kg";
searchMusicCommon(rawKw, group, isGroup?senderUin:peerUin, isGroup, msg);
}
} catch (Exception e) {}
}
class SearchResult {
public String type;
public JSONArray data;
public long timestamp;
public String searchKey;
}
String readFileText(String filePath) throws Exception {
File file=new File(filePath);
FileInputStream fis=new FileInputStream(file);
byte[] buf=new byte[(int) file.length()];
fis.read(buf);
fis.close();
return new String(buf);
}
String getPropValue(String key) {
try {
String propText=readFileText(pluginPath+"/info.prop");
if (propText.isEmpty()) return "";
String[] lines=propText.split("\n");
for (String line:lines) {
line=line.trim();
if (line.startsWith(key+"=")) return line.substring(key.length()+1);
}
} catch (Exception e) {}
return "";
}
void k(String msg, String url, String remoteVer) {
Activity activity=getNowActivity();
if (activity==null) return;
activity.runOnUiThread(new Runnable() {
public void run() {
TextView titleTextView=new TextView(activity);
titleTextView.setText(msg);
titleTextView.setTextColor(Color.BLACK);
titleTextView.setPadding(0,0,0,16);
LinearLayout layout=new LinearLayout(activity);
layout.setOrientation(LinearLayout.VERTICAL);
layout.setPadding(40,40,40,40);
layout.addView(titleTextView);
AlertDialog.Builder dialogBuilder=new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
dialogBuilder.setCancelable(false)
.setTitle("发现新版本 v"+remoteVer)
.setView(layout)
.setPositiveButton("更新", null);
AlertDialog dialog=dialogBuilder.create();
dialog.show();
View btn=dialog.getButton(DialogInterface.BUTTON_POSITIVE);
btn.setTextColor(Color.parseColor("#007aff"));
btn.setOnTouchListener(new View.OnTouchListener() {
Handler h=new Handler();
boolean closed=false;
Runnable closeRun=new Runnable(){
public void run(){
closed=true;
dialog.dismiss();
activity.runOnUiThread(new Runnable(){
public void run(){
toast("已跳过本次更新");
}
});
}
};
public boolean onTouch(View v, MotionEvent e) {
if(e.getAction()==MotionEvent.ACTION_DOWN){
closed=false;
h.postDelayed(closeRun,500);
}else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){
h.removeCallbacks(closeRun);
if(!closed){
new Thread(new Runnable(){
public void run(){
String zip=pluginPath+"/Java.zip";
try {
httpDownload(url,zip);
decompressFile(zip);
new File(zip).delete();
activity.runOnUiThread(new Runnable(){
public void run(){
toast("更新成功,请重新加载脚本");
}
});
} catch (Exception er) {}
}
}).start();
}
dialog.dismiss();
}
return true;
}
});
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.WHITE);
bg.setCornerRadius(20);
dialog.getWindow().setBackgroundDrawable(bg);
}
});
}
void extractFile(ZipInputStream zis, String path) throws Exception {
BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(path));
byte[] buf=new byte[1024];int len;
while ((len=zis.read(buf))!=-1) bos.write(buf,0,len);
bos.close();
}
void decompressFile(String zipPath) throws Exception {
File zip=new File(zipPath);
String dir=zip.getParent();
FileInputStream fis=new FileInputStream(zip);
ZipInputStream zis=new ZipInputStream(fis);
ZipEntry entry;
while ((entry=zis.getNextEntry())!=null) {
String full=dir+File.separator+entry.getName();
if(entry.isDirectory()) new File(full).mkdirs();
else extractFile(zis,full);
zis.closeEntry();
}
zis.close();fis.close();
}
void chatInterface(int chatType, String peerUin, String name) {
new Thread(new Runnable() {
public void run() {
try {
String realUrl=new String(Base64.getDecoder().decode(upd));
String jsonStr=httpGet(realUrl);
JSONObject json=new JSONObject(jsonStr);
String remoteVer=json.getString("bb");
String log=json.getString("nr");
String dlUrl=json.getString("url");
String local=getPropValue("versionCode");
Activity act=getNowActivity();
if (!local.isEmpty()&&!local.equals(remoteVer)) {
if(act!=null) act.runOnUiThread(new Runnable(){
public void run(){
k(log,dlUrl,remoteVer);
}
});
}
} catch (Exception e) {}
}
}).start();
}
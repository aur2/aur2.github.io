import java.io.*;
import java.net.*;
import java.util.zip.*;
import android.app.Activity;
import android.content.DialogInterface;
import org.json.JSONObject;
import android.text.Html;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
String localVersion="2.0";
void k(String msg,String url,String bb) {
Activity activity=getActivity();
activity.runOnUiThread(new Runnable() {
public void run() {
TextView titleTextView=new TextView(activity);
titleTextView.setText(Html.fromHtml("<font color=\"#000000\">"+msg+"</font>"));
titleTextView.setPadding(0,0,0,16);
LinearLayout layout=new LinearLayout(activity);
layout.setOrientation(LinearLayout.VERTICAL);
layout.setPadding(40,40,40,40);
layout.addView(titleTextView);
AlertDialog.Builder dialogBuilder=new AlertDialog.Builder(activity,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
dialogBuilder.setCancelable(false)
.setTitle(Html.fromHtml("<font color=\"#000000\">发现新版本</font>"))
.setView(layout)
.setPositiveButton("更新", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface dialogInterface,int i) {
new Thread(new Runnable() {
public void run() {
String zipPath=appPath+"/糖豆子java.zip";
if (DownloadToFile(url, zipPath)) {
decompressFile(zipPath);
new File(zipPath).delete();
activity.runOnUiThread(()->toast("更新成功,请重新加载脚本"));
}else{
activity.runOnUiThread(()->toast("下载失败"));
}
}
}).start();
}
})
.setNegativeButton("稍后再说",null);
AlertDialog dialog=dialogBuilder.create();
GradientDrawable dialogBg=new GradientDrawable();
dialogBg.setColor(Color.WHITE);
dialogBg.setCornerRadius(20);
dialog.getWindow().setBackgroundDrawable(dialogBg);
dialog.show();
}
});
}
String httpget(String urlString) throws IOException {
URL url=new URL(urlString);
URLConnection conn=url.openConnection();
InputStream is=conn.getInputStream();
BufferedReader br=new BufferedReader(new InputStreamReader(is));
StringBuilder sb=new StringBuilder();
String line;
while ((line=br.readLine())!=null) sb.append(line);
br.close();
is.close();
return sb.toString();
}
public static boolean DownloadToFile(String fileUrl, String savePath) {
try {
URL url=new URL(fileUrl);
URLConnection conn=url.openConnection();
InputStream is=conn.getInputStream();
FileOutputStream fos=new FileOutputStream(savePath);
byte[] buf=new byte[1024];
int len;
while ((len=is.read(buf))!=-1) fos.write(buf, 0, len);
fos.close();
is.close();
return true;
} catch (Exception e) {
return false;
}
}
private static void extractFile(ZipInputStream zis, String path) throws IOException {
BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(path));
byte[] buf=new byte[1024];
int len;
while ((len=zis.read(buf))!=-1) bos.write(buf, 0, len);
bos.close();
}
public static void decompressFile(String zipPath) {
try {
File zip=new File(zipPath);
String outDir=zip.getParent();
FileInputStream fis=new FileInputStream(zip);
ZipInputStream zis=new ZipInputStream(fis);
ZipEntry entry;
while ((entry=zis.getNextEntry())!=null) {
String fullPath=outDir+File.separator+entry.getName();
if (entry.isDirectory()) new File(fullPath).mkdir();
else extractFile(zis, fullPath);
zis.closeEntry();
}
zis.close();
fis.close();
} catch (Exception e) {}
}
void onLoad() {
new Thread(()->{
try{
String jsonStr=httpget("https://aur2.github.io/assets/qs.json");
JSONObject json=new JSONObject(jsonStr);
String remoteVer=json.getString("bb");
String updateLog=json.getString("nr");
String downloadUrl=json.getString("url");
if(!localVersion.equals(remoteVer)){
Activity activity=getActivity();
activity.runOnUiThread(()->k(updateLog,downloadUrl,remoteVer));
}
}catch (Exception e){
}
}).start();
}
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.BitmapFactory;
import java.io.FileOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.net.HttpURLConnection;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.util.HashMap;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.ProgressBar;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import android.view.Gravity;
import android.content.Context;
import android.text.TextWatcher;
import android.text.Editable;
import com.tencent.mobileqq.music.api.IQQPlayer;
import com.tencent.mobileqq.music.SongInfo;
import com.tencent.mobileqq.qroute.QRoute;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import android.text.Html;
import android.view.MotionEvent;
import android.os.Handler;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.io.FileInputStream;
import java.io.BufferedOutputStream;
String[] qqkey={"点歌", "QQ点歌"};
String[] wykey={"网易点歌", "wy点歌"};
String configName="ql_kg";
String privateConfigName="sl_kg";
String modeConfigName="ql_ms";
String privateModeConfigName="sl_ms";
String listModeConfig="lb_kg";
String limitConfigName="qx_kg";
String historyConfig="ss_ls";
HashMap<String, SearchResult>search_results=new HashMap<>();
List<String>searchHistory=new ArrayList<>();
String myWeb_qq="aHR0cHM6Ly9hLmFhLmNhYi9xcS5tdXNpYw==";
String myWeb_wy="aHR0cHM6Ly9hLmFhLmNhYi93eS5tdXNpYw==";
String upd="aHR0cHM6Ly9hdXIyLmdpdGh1Yi5pby9hc3NldHMvcXMvdXBkLmpzb24=";
final Object lock=new Object();
String currentPlatform="qq";
LinearLayout rootLayout;
LinearLayout resultContainer;
AlertDialog mainSearchDialog;
LinearLayout historyLayout;
addItem("开/关点歌", "xiafeng2017");
addItem("搜索歌曲", "xiafeng2018");
private String sec(String str) {
try {
byte[] bytes=Base64.getDecoder().decode(str.trim());
return new String(bytes, StandardCharsets.UTF_8).trim();
} catch (Exception e) {
error(e);
return "";
}
}
private String cleanKw(String raw) {
if (raw==null) return "";
String temp=raw.replaceAll("[\\n\\r\\t]", " ");
temp=temp.replaceAll("\\s+", " ");
return temp.trim();
}
private void loadHistory() {
try {
String historyStr=getString(historyConfig, "", "");
searchHistory.clear();
if (historyStr!=null&&!historyStr.isEmpty()) {
String[] arr=historyStr.split("\\|");
for (String s:arr) {
if (s!=null&&!s.trim().isEmpty()) {
searchHistory.add(s.trim());
}
}
}
} catch (Exception e) {
error(e);
}
}
private void saveHistory() {
try {
StringBuilder sb=new StringBuilder();
for (int i=0; i<searchHistory.size(); i++) {
if (i>0) sb.append("|");
sb.append(searchHistory.get(i));
}
putString(historyConfig, "", sb.toString());
} catch (Exception e) {
error(e);
}
}
private void addToHistory(String keyword) {
if (keyword==null||keyword.trim().isEmpty()) return;
String k=keyword.trim();
searchHistory.remove(k);
searchHistory.add(0, k);
saveHistory();
}
public void xiafeng2017(String groupUin, String uin, int chatType) {
if (chatType==2) {
boolean now=getBoolean(configName, groupUin, false);
putBoolean(configName, groupUin, !now);
toast(!now?"已开启本群点歌":"已关闭本群点歌");
}else{
boolean now=getBoolean(privateConfigName, uin, false);
putBoolean(privateConfigName, uin, !now);
toast(!now?"已开启私聊点歌":"已关闭私聊点歌");
}
}
public void xiafeng2018(final String groupUin, final String uin, final int chatType) {
loadHistory();
final boolean isGroup=chatType==2;
final Activity activity=getNowActivity();
activity.runOnUiThread(new Runnable() {
public void run() {
AlertDialog.Builder builder=new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
builder.setTitle("搜索歌曲𝒥𝒶𝓋𝒶");
LinearLayout outerRoot=new LinearLayout(activity);
outerRoot.setOrientation(LinearLayout.VERTICAL);
outerRoot.setPadding(40, 40, 40, 40);
LinearLayout fixTopLayout=new LinearLayout(activity);
fixTopLayout.setOrientation(LinearLayout.VERTICAL);
LinearLayout btnLayout=new LinearLayout(activity);
btnLayout.setOrientation(LinearLayout.HORIZONTAL);
btnLayout.setGravity(Gravity.END);
btnLayout.setPadding(0, 0, 0, 12);
final TextView tvPlatform=new TextView(activity);
String platStr="QQ";
if ("wy".equals(currentPlatform)) {
platStr="网易";
}
tvPlatform.setText("平台："+platStr);
tvPlatform.setTextSize(11);
tvPlatform.setTextColor(Color.parseColor("#123456"));
tvPlatform.setPadding(12, 6, 12, 6);
GradientDrawable bgPlatform=new GradientDrawable();
bgPlatform.setColor(Color.parseColor("#ffffff"));
bgPlatform.setCornerRadius(16);
bgPlatform.setStroke(2, Color.parseColor("#aaBEE7"));
tvPlatform.setBackground(bgPlatform);
LinearLayout.LayoutParams lpPlatform=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
lpPlatform.setMargins(0, 0, 12, 0);
tvPlatform.setLayoutParams(lpPlatform);
tvPlatform.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
if ("qq".equals(currentPlatform)) {
currentPlatform="wy";
toast("已切换：网易音乐");
tvPlatform.setText("平台：网易");
}else{
currentPlatform="qq";
toast("已切换：QQ音乐");
tvPlatform.setText("平台：QQ");
}
}
});
final TextView tvMode=new TextView(activity);
String mode=isGroup?getString(modeConfigName, groupUin, "card"):getString(privateModeConfigName, uin, "card");
String showMode="卡片";
if ("voice".equals(mode)) showMode="语音";
if ("qq_player".equals(mode)) showMode="播放";
tvMode.setText("模式："+showMode);
tvMode.setTextSize(11);
tvMode.setTextColor(Color.parseColor("#123456"));
tvMode.setPadding(12, 6, 12, 6);
GradientDrawable bgMode=new GradientDrawable();
bgMode.setColor(Color.parseColor("#ffffff"));
bgMode.setCornerRadius(16);
bgMode.setStroke(2, Color.parseColor("#aaBEE7"));
tvMode.setBackground(bgMode);
LinearLayout.LayoutParams lpMode=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
lpMode.setMargins(0, 0, 12, 0);
tvMode.setLayoutParams(lpMode);
tvMode.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
String nowMode=isGroup?getString(modeConfigName, groupUin, "card"):getString(privateModeConfigName, uin, "card");
String newMode="card";
String tip="卡片";
if ("card".equals(nowMode)) {
newMode="voice";
tip="语音";
} else if ("voice".equals(nowMode)) {
newMode="qq_player";
tip="播放";
} else if ("qq_player".equals(nowMode)) {
newMode="card";
tip="卡片";
}
if (isGroup) {
putString(modeConfigName, groupUin, newMode);
}else{
putString(privateModeConfigName, uin, newMode);
}
tvMode.setText("模式："+tip);
toast("已切换："+tip);
}
});
final TextView tvList=new TextView(activity);
tvList.setText(getBoolean(listModeConfig, groupUin, false)?"列表：开":"列表：关");
tvList.setTextSize(11);
tvList.setTextColor(Color.parseColor("#123456"));
tvList.setPadding(12, 6, 12, 6);
GradientDrawable bgList=new GradientDrawable();
bgList.setColor(Color.parseColor("#ffffff"));
bgList.setCornerRadius(16);
bgList.setStroke(2, Color.parseColor("#aaBEE7"));
tvList.setBackground(bgList);
LinearLayout.LayoutParams lpList=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
lpList.setMargins(0, 0, 12, 0);
tvList.setLayoutParams(lpList);
tvList.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
boolean now=getBoolean(listModeConfig, groupUin, false);
putBoolean(listModeConfig, groupUin, !now);
tvList.setText(!now?"列表：开":"列表：关");
toast(!now?"已开启列表模式":"已关闭列表模式");
}
});
final TextView tvLimit=new TextView(activity);
tvLimit.setText(getBoolean(limitConfigName, groupUin, false)?"限制：开":"限制：关");
tvLimit.setTextSize(11);
tvLimit.setTextColor(Color.parseColor("#123456"));
tvLimit.setPadding(12, 6, 12, 6);
GradientDrawable bgLimit=new GradientDrawable();
bgLimit.setColor(Color.parseColor("#ffffff"));
bgLimit.setCornerRadius(16);
bgLimit.setStroke(2, Color.parseColor("#aaBEE7"));
tvLimit.setBackground(bgLimit);
tvLimit.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
boolean now=getBoolean(limitConfigName, groupUin, false);
putBoolean(limitConfigName, groupUin, !now);
tvLimit.setText(!now?"已开启本群限制":"已关闭本群限制");
toast(!now?"已开启本群限制":"已关闭本群限制");
}
});
btnLayout.addView(tvPlatform);
btnLayout.addView(tvMode);
btnLayout.addView(tvList);
btnLayout.addView(tvLimit);
fixTopLayout.addView(btnLayout);
LinearLayout searchRow=new LinearLayout(activity);
searchRow.setOrientation(LinearLayout.HORIZONTAL);
searchRow.setPadding(0, 8, 0, 8);
final EditText editText=createEditText(activity, "");
editText.setHint("请输入歌曲名...");
editText.setHintTextColor(Color.parseColor("#999999"));
editText.setSingleLine(true);
editText.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
editText.addTextChangedListener(new TextWatcher() {
public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
public void onTextChanged(CharSequence s, int start, int before, int count) {
String content=s.toString().trim();
if (content.isEmpty()) {
resultContainer.removeAllViews();
if (historyLayout!=null) {
historyLayout.setVisibility(View.VISIBLE);
}
}
}
public void afterTextChanged(Editable s) {}
});
LinearLayout.LayoutParams etLp=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
editText.setLayoutParams(etLp);
Button searchBtn=new Button(activity);
searchBtn.setText("搜索");
GradientDrawable btnBg=new GradientDrawable();
btnBg.setColor(Color.parseColor("#aaBEE7"));
btnBg.setCornerRadius(30);
searchBtn.setBackground(btnBg);
searchBtn.setTextColor(Color.parseColor("#123456"));
LinearLayout.LayoutParams btnLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
btnLp.setMargins(12, 0, 0, 0);
searchBtn.setLayoutParams(btnLp);
final Runnable searchRunnable=new Runnable() {
public void run() {
String key=editText.getText().toString();
String cleanKw=cleanKw(key);
if (cleanKw.isEmpty()) {
resultContainer.removeAllViews();
toast("输入为空");
return;
}
if (historyLayout!=null) {
historyLayout.setVisibility(View.GONE);
}
addToHistory(cleanKw);
searchAndShowList(key, groupUin, uin, chatType==2, false);
}
};
searchBtn.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
InputMethodManager imm=(InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
searchRunnable.run();
}
});
editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
if (actionId==EditorInfo.IME_ACTION_SEARCH) {
InputMethodManager imm=(InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
searchRunnable.run();
return true;
}
return false;
}
});
searchRow.addView(editText);
searchRow.addView(searchBtn);
fixTopLayout.addView(searchRow);
if (searchHistory!=null&&!searchHistory.isEmpty()) {
historyLayout=new LinearLayout(activity);
historyLayout.setOrientation(LinearLayout.VERTICAL);
historyLayout.setPadding(0, 16, 0, 8);
LinearLayout historyHead=new LinearLayout(activity);
historyHead.setOrientation(LinearLayout.HORIZONTAL);
historyHead.setGravity(Gravity.CENTER_VERTICAL);
TextView historyTitle=new TextView(activity);
historyTitle.setText("搜索历史");
historyTitle.setTextSize(13);
historyTitle.setTextColor(Color.parseColor("#666666"));
LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
historyTitle.setLayoutParams(titleParams);
Button clearBtn=new Button(activity);
clearBtn.setText(" 🗑️ ");
clearBtn.setTextSize(11);
clearBtn.setBackgroundColor(Color.TRANSPARENT);
clearBtn.setTextColor(Color.parseColor("#666666"));
clearBtn.setPadding(8, 2, 8, 2);
clearBtn.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
searchHistory.clear();
saveHistory();
fixTopLayout.removeView(historyLayout);
toast("已清空历史");
}
});
historyHead.addView(historyTitle);
historyHead.addView(clearBtn);
historyLayout.addView(historyHead);
LinearLayout flowContainer=new LinearLayout(activity);
flowContainer.setOrientation(LinearLayout.VERTICAL);
flowContainer.setPadding(0, 8, 0, 0);
LinearLayout currentRow=new LinearLayout(activity);
currentRow.setOrientation(LinearLayout.HORIZONTAL);
currentRow.setPadding(0, 4, 0, 4);
flowContainer.addView(currentRow);
final int maxRowWidth=860;
int usedW=0;
for (int i=0; i<searchHistory.size(); i++) {
String kw=searchHistory.get(i);
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.parseColor("#EEEEEE"));
bg.setCornerRadius(20);
final TextView tv=new TextView(activity);
tv.setText(kw);
tv.setTextSize(13);
tv.setTextColor(Color.parseColor("#333333"));
tv.setBackground(bg);
tv.setPadding(14, 6, 14, 6);
LinearLayout.LayoutParams tvLp=new LinearLayout.LayoutParams(
LinearLayout.LayoutParams.WRAP_CONTENT,
LinearLayout.LayoutParams.WRAP_CONTENT
);
tvLp.setMargins(6, 4, 6, 4);
tv.setLayoutParams(tvLp);
tv.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
String key=((TextView) v).getText().toString();
InputMethodManager imm=(InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
editText.setText(key);
editText.setSelection(key.length());
if (historyLayout!=null) historyLayout.setVisibility(View.GONE);
String cleanKw=cleanKw(key);
addToHistory(cleanKw);
searchAndShowList(key, groupUin, uin, chatType==2, false);
}
});
tv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
int tagFull=tv.getMeasuredWidth()+tvLp.leftMargin+tvLp.rightMargin;
if (usedW+tagFull>maxRowWidth) {
currentRow=new LinearLayout(activity);
currentRow.setOrientation(LinearLayout.HORIZONTAL);
currentRow.setPadding(0, 4, 0, 4);
flowContainer.addView(currentRow);
usedW=0;
}
currentRow.addView(tv);
usedW+=tagFull;
}
historyLayout.addView(flowContainer);
fixTopLayout.addView(historyLayout);
}
ScrollView scrollView=new ScrollView(activity);
scrollView.setVerticalScrollBarEnabled(false);
scrollView.setHorizontalScrollBarEnabled(false);
resultContainer=new LinearLayout(activity);
resultContainer.setOrientation(LinearLayout.VERTICAL);
resultContainer.setPadding(0, 20, 0, 0);
scrollView.addView(resultContainer);
LinearLayout.LayoutParams fixLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
LinearLayout.LayoutParams scrollLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
outerRoot.addView(fixTopLayout, fixLp);
outerRoot.addView(scrollView, scrollLp);
rootLayout=outerRoot;
builder.setView(outerRoot);
builder.setPositiveButton("", null);
final AlertDialog dialog=builder.create();
mainSearchDialog=dialog;
UI(dialog);
dialog.show();
dialog.getWindow().setLayout(980,-2);
dialog.getButton(DialogInterface.BUTTON_POSITIVE).setVisibility(View.GONE);
editText.requestFocus();
new android.os.Handler().postDelayed(new Runnable() {
public void run() {
((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(editText, 2);
}
}, 200);
}
});
}
public void searchAndShowList(final String key, final String group, final String uin, final boolean isGroup, final boolean closeDialog) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(key);
if(cleanKw.isEmpty()){
throw new Exception();
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url="";
if ("qq".equals(currentPlatform)) {
url=sec(myWeb_qq)+"?msg="+encoded+"&num=20";
} else if ("wy".equals(currentPlatform)) {
url=sec(myWeb_wy)+"?msg="+encoded+"&num=20";
}
String resp=httpGet(url);
if (resp==null||resp.trim().isEmpty()) {
throw new Exception();
}
JSONObject json=new JSONObject(resp);
int code=json.getInt("code");
JSONArray data=json.getJSONArray("data");
if (code!=0||data.length()==0) {
throw new Exception();
}
final List<String>names=new ArrayList<>();
final List<Object>ids=new ArrayList<>();
for (int i=0; i<data.length(); i++) {
JSONObject item=data.getJSONObject(i);
String title;
String author;
if ("qq".equals(currentPlatform)) {
title=item.optString("song", "未知歌曲");
author=item.optString("singer", "未知歌手");
}else{
title=item.optString("title", item.optString("song", "未知歌曲"));
author=item.optString("author", item.optString("singer", "未知歌手"));
}
names.add((i+1)+". "+title+"-"+author);
ids.add(i+1);
}
final Activity act=getNowActivity();
act.runOnUiThread(new Runnable() {
public void run() {
resultContainer.removeAllViews();
final String clickMode=isGroup?getString(modeConfigName, group, "card"):getString(privateModeConfigName, uin, "card");
for (int i=0; i<names.size(); i++) {
String itemText=names.get(i);
final Object idObj=ids.get(i);
LinearLayout itemLayout=new LinearLayout(act);
itemLayout.setOrientation(LinearLayout.HORIZONTAL);
itemLayout.setGravity(Gravity.CENTER_VERTICAL);
itemLayout.setPadding(15, 12, 15, 12);
GradientDrawable itemBg=new GradientDrawable();
itemBg.setColor(Color.parseColor("#f7f7f7"));
itemBg.setCornerRadius(12);
itemBg.setStroke(1, Color.parseColor("#dddddd"));
itemLayout.setBackground(itemBg);
TextView itemTv=new TextView(act);
itemTv.setText(itemText);
itemTv.setTextSize(14);
itemTv.setTextColor(Color.parseColor("#333333"));
LinearLayout.LayoutParams tvLp=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
itemTv.setLayoutParams(tvLp);
ProgressBar itemProgress=new ProgressBar(act);
itemProgress.setVisibility(View.GONE);
LinearLayout.LayoutParams proLp=new LinearLayout.LayoutParams(35, 35);
proLp.setMargins(10, 0, 0, 0);
itemProgress.setLayoutParams(proLp);
itemLayout.addView(itemTv);
itemLayout.addView(itemProgress);
LinearLayout.LayoutParams itemLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
itemLp.setMargins(0, 6, 0, 0);
itemLayout.setLayoutParams(itemLp);
itemLayout.setTag(new Object[]{idObj, itemProgress});
itemLayout.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
Object[] tagArr=(Object[]) v.getTag();
Object realId=tagArr[0];
ProgressBar proBar=(ProgressBar) tagArr[1];
act.runOnUiThread(()->proBar.setVisibility(View.VISIBLE));
if ("qq".equals(currentPlatform)) {
getMusicByIndex_qq(key, (Integer) realId, group, uin, isGroup, proBar);
} else if ("wy".equals(currentPlatform)) {
getMusicByIndex_wy(key, (Integer) realId, group, uin, isGroup, proBar, 20);
}
}
});
resultContainer.addView(itemLayout);
}
if (closeDialog&&mainSearchDialog!=null) mainSearchDialog.dismiss();
}
});
} catch (Exception e) {
error(e);
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
toast("获取失败,请稍后重试。");
}
});
}
}
}).start();
}
public void getMusicByIndex_qq(final String songName, final int index, final String group, final String uin, final boolean isGroup, ProgressBar bar) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(songName);
if(cleanKw.isEmpty()){
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url=sec(myWeb_qq)+"?msg="+encoded+"&num=20&n="+index;
String response=httpGet(url);
if (response==null||response.trim().isEmpty()) {
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject json=new JSONObject(response);
int code=json.getInt("code");
if(code != 0){
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject data=json.getJSONObject("data");
String title=data.optString("song", "未知歌曲");
String singer=data.optString("singer", "未知歌手");
String coverUrl=data.optString("cover");
String musicUrl=data.optString("music");
if (title.isEmpty()||musicUrl.isEmpty()) {
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, "qq", bar);
} catch (Exception e) {
error(e);
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
public void getMusicByIndex_wy(final String songName, final int index, final String group, final String uin, final boolean isGroup, ProgressBar bar, int numCount) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(songName);
if(cleanKw.isEmpty()){
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url=sec(myWeb_wy)+"?msg="+encoded+"&num="+numCount+"&n="+index;
String response=httpGet(url);
if (response==null||response.trim().isEmpty()) {
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
return;
}
JSONObject json=new JSONObject(response);
JSONObject data=json.getJSONObject("data");
String title=data.optString("song", "未知歌曲");
String singer=data.optString("singer", "未知歌手");
String coverUrl=data.optString("cover");
String musicUrl=data.optString("music");
if (title.isEmpty()||musicUrl.isEmpty()) {
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
return;
}
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, "163", bar);
} catch (Exception e) {
error(e);
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
private void addTextView(LinearLayout container, Activity activity, String text) {
TextView textView=new TextView(activity);
textView.setText(text);
textView.setTextSize(14);
textView.setTextColor(Color.parseColor("#123456"));
LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
);
params.topMargin=24;
params.bottomMargin=8;
textView.setLayoutParams(params);
container.addView(textView);
}
private EditText createEditText(Activity activity, String defaultValue) {
EditText editText=new EditText(activity);
editText.setText(defaultValue==null?"":defaultValue);
editText.setTextSize(14);
editText.setMinHeight(120);
editText.setPadding(40, 24, 40, 24);
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.parseColor("#ffffff"));
bg.setCornerRadius(30);
bg.setStroke(2, Color.parseColor("#aaBEE7"));
editText.setBackground(bg);
LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
);
params.bottomMargin=16;
editText.setLayoutParams(params);
return editText;
}
public void UI(AlertDialog dialog) {
GradientDrawable gradientDrawable=new GradientDrawable();
gradientDrawable.setColor(Color.parseColor("#aaBEE7"));
gradientDrawable.setCornerRadius(50);
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
dialog.getWindow().setDimAmount(0.2f);
}else{
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
}
WindowManager.LayoutParams params=dialog.getWindow().getAttributes();
params.alpha=0.9f;
dialog.getWindow().setAttributes(params);
dialog.setOnShowListener(new DialogInterface.OnShowListener() {
public void onShow(DialogInterface dialogInterface) {
setBtnColor(dialog, DialogInterface.BUTTON_POSITIVE);
setBtnColor(dialog, DialogInterface.BUTTON_NEGATIVE);
}
});
}
private void setBtnColor(AlertDialog dialog, int btn) {
dialog.getButton(btn).setTextColor(Color.parseColor("#123456"));
}
public Activity getNowActivity() {
return getActivity();
}
public Bitmap downloadCover(String coverUrl) {
try {
return BitmapFactory.decodeStream(new URL(coverUrl).openStream());
} catch (Exception e) {
error(e);
return null;
}
}
public void sendTipMsg(String target, boolean isGroup, String tip) {
if (isGroup) {
sendMsg(target, "", tip);
}else{
sendMsg("", target, tip);
}
}
public boolean sendMusicCard(String targetUin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt) {
try {
String encodedUrl=URLEncoder.encode(musicUrl, "UTF-8");
String encodedCover=URLEncoder.encode(coverUrl, "UTF-8");
String encodedTitle=URLEncoder.encode(title, "UTF-8");
String encodedSinger=URLEncoder.encode(singer, "UTF-8");
String apiUrl="https://oiapi.net/API/QQMusicJSONArk?format="+fmt+"&url="+encodedUrl+"&song="+encodedTitle+"&singer="+encodedSinger+"&cover="+encodedCover+"&jump="+encodedUrl;
String arkResponse=httpGet(apiUrl);
if (arkResponse==null||arkResponse.trim().isEmpty()) return false;
JSONObject arkJson=new JSONObject(arkResponse);
if (arkJson.getInt("code")==1) {
String cardJson=arkJson.getString("message");
if (isGroup) {
sendCard(targetUin, "", cardJson);
}else{
sendCard("", targetUin, cardJson);
}
return true;
}
} catch (Exception e) {
error(e);
}
return false;
}
public void generateSearchListImage(JSONArray data, String coverUrl, String target, boolean isGroup, Object msg) {
new Thread(new Runnable() {
public void run() {
synchronized (lock) {
try {
int displayCount=Math.min(data.length(), 15);
int itemHeight=70;
int topPadding=60;
int leftPadding=60;
int width=1080;
int height=topPadding+60+displayCount*itemHeight+80+60;
Bitmap bitmap=Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
Canvas canvas=new Canvas(bitmap);
canvas.drawColor(Color.parseColor("#FAFBFC"));
Bitmap coverBmp=downloadCover(coverUrl);
if (coverBmp != null) {
Paint coverPaint=new Paint();
coverPaint.setAlpha(70);
Bitmap scaledCover=Bitmap.createScaledBitmap(coverBmp, width, height, true);
canvas.drawBitmap(scaledCover, 0, 0, coverPaint);
scaledCover.recycle();
coverBmp.recycle();
}
Paint titlePaint=new Paint();
titlePaint.setColor(Color.parseColor("#222222"));
titlePaint.setTextSize(48);
titlePaint.setAntiAlias(true);
titlePaint.setFakeBoldText(true);
float y=topPadding;
canvas.drawText("搜索结果:", leftPadding, y, titlePaint);
y+=itemHeight-10;
y+=25;
Paint textPaint=new Paint();
textPaint.setColor(Color.parseColor("#333333"));
textPaint.setTextSize(40);
textPaint.setAntiAlias(true);
for (int i=0; i<displayCount; i++) {
JSONObject item=data.getJSONObject(i);
String title;
String singer;
if ("qq".equals(currentPlatform)) {
title=item.optString("song", "未知");
singer=item.optString("singer", "未知");
}else{
title=item.optString("title", item.optString("song", "未知"));
singer=item.optString("author", item.optString("singer", "未知"));
}
String line=(i+1)+"、"+title+"-"+singer;
canvas.drawText(line, leftPadding, y, textPaint);
y+=itemHeight;
}
Paint tipPaint=new Paint();
tipPaint.setColor(Color.parseColor("#666666"));
tipPaint.setTextSize(36);
tipPaint.setAntiAlias(true);
canvas.drawText("请发送序号选择（1～15）,120秒内有效。", leftPadding, height-60, tipPaint);
String path=appPath+"/search_list.png";
FileOutputStream fos=new FileOutputStream(path);
bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
fos.close();
bitmap.recycle();
String pic="[PicUrl="+path+"]";
if (isGroup) {
sendReply(target, msg, pic);
}else{
sendMsg("", target, pic);
}
new File(path).delete();
} catch (Exception e) {
error(e);
}
}
}
}).start();
}
public void processMusicSelection(String text, String uin, String group, boolean isGroup) {
try {
if (!text.matches("[0-9]+")||text.length()>2) return;
int index=Integer.parseInt(text);
String key=group+"_"+uin;
if (!search_results.containsKey(key)) return;
SearchResult result=search_results.get(key);
if (result==null||result.data==null||index>15) return;
if (System.currentTimeMillis()-result.timestamp>120*1000) {
search_results.remove(key);
return;
}
if ("qq".equals(result.type)) {
String songName=result.searchKey;
getMusicByIndex_qq(songName, index, group, uin, isGroup, null);
} else if ("wy".equals(result.type)) {
JSONObject item=result.data.getJSONObject(index-1);
String songName=item.optString("song");
getMusicByIndex_wy(songName, index, group, uin, isGroup, null, 15);
}
} catch (Exception e) {
error(e);
}
}
public void showErrorTip(String targetGroup, String targetUin, boolean isGroup) {
sendTipMsg(isGroup?targetGroup:targetUin, isGroup, "获取失败,请稍后重试。");
}
public void playMusicByQQ(String song, String singer, String link, String musicUrl, String cover, String type) {
try {
Context context=getNowActivity();
SongInfo info=new SongInfo(1L, cover, musicUrl);
info.e=singer;
info.i=song;
info.m=link;
QRoute.api(IQQPlayer.class).startPlayMusic(context, type, new SongInfo[]{info});
} catch (Exception e) {
error(e);
}
}
public void sendMusicResult(String group, String uin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt, ProgressBar bar) {
String mode=isGroup?getString(modeConfigName, group, "card"):getString(privateModeConfigName, uin, "card");
boolean showTip=false;
if ("card".equals(mode)) {
boolean ok=sendMusicCard(isGroup?group:uin, title, singer, coverUrl, musicUrl, isGroup, fmt);
if (ok) {
showTip=true;
if (mainSearchDialog!=null) mainSearchDialog.dismiss();
}
} else if ("voice".equals(mode)) {
Context appContext=getNowActivity().getApplicationContext();
File tempAudioFile=new File(appContext.getCacheDir(), System.currentTimeMillis()+".mp3");
String path=tempAudioFile.getAbsolutePath();
httpDownload(musicUrl, path);
if (isGroup) sendVoice(group, "", path);
else sendVoice("", uin, path);
if (tempAudioFile.exists()) {
tempAudioFile.delete();
}
showTip=true;
if (mainSearchDialog!=null) mainSearchDialog.dismiss();
} else if ("qq_player".equals(mode)) {
showTip=true;
String qType="qmp_play";
if ("163".equals(fmt)) qType="wy";
playMusicByQQ(title, singer, musicUrl, musicUrl, coverUrl, qType);
}
if (showTip) {
toast("已发送");
}
if (bar!=null) {
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
}
}
public void sendMusicResult(String group, String uin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt) {
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, fmt, null);
}
public void searchMusicCommon(String songName, String group, String uin, boolean isGroup, Object msg) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(songName);
if(cleanKw.isEmpty()){
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url="";
String type="";
if ("qq".equals(currentPlatform)) {
url=sec(myWeb_qq)+"?msg="+encoded+"&num=15";
type="qq";
} else if ("wy".equals(currentPlatform)) {
url=sec(myWeb_wy)+"?msg="+encoded+"&num=15";
type="wy";
}
String resp=httpGet(url);
JSONObject json=new JSONObject(resp);
int code=json.getInt("code");
if(code != 0){
showErrorTip(group, uin, isGroup);
return;
}
JSONArray data=json.getJSONArray("data");
String key=group+"_"+uin;
boolean listEnabled=getBoolean(listModeConfig, group, false);
if (listEnabled) {
SearchResult r=new SearchResult();
r.type=type;
r.data=data;
r.timestamp=System.currentTimeMillis();
r.searchKey=cleanKw;
search_results.put(key, r);
String cover="";
if (data.length()>0) {
if ("qq".equals(type)) {
cover=data.getJSONObject(0).optString("cover");
}else{
cover=data.getJSONObject(0).optString("cover", data.getJSONObject(0).optString("picture"));
}
}
generateSearchListImage(data, cover, isGroup?group:uin, isGroup, msg);
}else{
if ("qq".equals(currentPlatform)) {
getMusicByIndex_qq(songName, 1, group, uin, isGroup, null);
} else if ("wy".equals(currentPlatform)) {
getMusicByIndex_wy(songName, 1, group, uin, isGroup, null, 15);
}
}
} catch (Exception e) {
error(e);
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
public void onMsg(Object msg) {
String text=msg.MessageContent;
String senderUin=msg.UserUin;
String group=msg.GroupUin;
String peerUin=msg.PeerUin;
boolean isGroup=msg.IsGroup;
boolean isSend=msg.IsSend;
if (isGroup&&getBoolean(limitConfigName, group, false)&&!isSend) return;
boolean listEnabled=getBoolean(listModeConfig, group, false);
if (listEnabled&&text.matches("[0-9]+")&&text.length()<=2) {
if (isGroup) {
if (getBoolean(configName, group, false)) {
processMusicSelection(text, senderUin, group, true);
}
}else{
if (getBoolean(privateConfigName, peerUin, false)) {
processMusicSelection(text, peerUin, "", false);
}
}
return;
}
boolean qqTrigger=false;
boolean wyTrigger=false;
String trigger=null;
for (String k:qqkey) {
if (text.startsWith(k)) {
qqTrigger=true;
trigger=k;
break;
}
}
if (!qqTrigger) {
for (String k:wykey) {
if (text.startsWith(k)) {
wyTrigger=true;
trigger=k;
break;
}
}
}
if (trigger!=null) {
if (isGroup&&!getBoolean(configName, group, false)) return;
if (!isGroup&&!getBoolean(privateConfigName, peerUin, false)) return;
String rawKw=text.substring(trigger.length());
String kw=cleanKw(rawKw);
if (kw.isEmpty()) {
sendTipMsg(isGroup?group:peerUin, isGroup, "请输入歌名");
return;
}
if (qqTrigger) currentPlatform="qq";
if (wyTrigger) currentPlatform="wy";
searchMusicCommon(rawKw, group, isGroup?senderUin:peerUin, isGroup, msg);
}
}
class SearchResult {
public String type;
public JSONArray data;
public long timestamp;
public String searchKey;
}
String getPropValue(String key) {
try {
String propText=readFileText(appPath+"/info.prop");
if (propText.isEmpty()) return "";
String[] lines=propText.split("\n");
for (String line:lines) {
line=line.trim();
if (line.startsWith(key+"=")) return line.substring(key.length()+1);
}
} catch (Exception e) {
error(e);
}
return "";
}
void k(String msg, String url) {
Activity activity=getActivity();
if (activity==null) return;
activity.runOnUiThread(new Runnable() {
public void run() {
TextView titleTextView=new TextView(activity);
titleTextView.setText(Html.fromHtml("<font color=\"#000000\">"+msg+"</font>"));
titleTextView.setPadding(0,0,0,16);
LinearLayout layout=new LinearLayout(activity);
layout.setOrientation(LinearLayout.VERTICAL);
layout.setPadding(40,40,40,40);
layout.addView(titleTextView);
AlertDialog.Builder dialogBuilder=new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
dialogBuilder.setCancelable(false)
.setTitle(Html.fromHtml("<font color=\"#000000\">发现新版本</font>"))
.setView(layout)
.setPositiveButton("更新", null);
AlertDialog dialog=dialogBuilder.create();
dialog.show();
View btn=dialog.getButton(DialogInterface.BUTTON_POSITIVE);
btn.setOnTouchListener(new View.OnTouchListener() {
Handler h=new Handler();
boolean closed=false;
Runnable closeRun=new Runnable(){
public void run(){
closed=true;
dialog.dismiss();
activity.runOnUiThread(new Runnable(){
public void run(){
toast("已跳过本次更新");
}
});
}
};
public boolean onTouch(View v, MotionEvent e) {
if(e.getAction()==MotionEvent.ACTION_DOWN){
closed=false;
h.postDelayed(closeRun,500);
}else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){
h.removeCallbacks(closeRun);
if(!closed){
new Thread(new Runnable(){
public void run(){
String zip=appPath+"/Java.zip";
try {
httpDownload(url,zip);
decompressFile(zip);
new File(zip).delete();
activity.runOnUiThread(new Runnable(){
public void run(){
toast("更新成功,请重新加载脚本");
}
});
} catch (Exception er) {
error(er);
}
}
}).start();
}
dialog.dismiss();
}
return true;
}
});
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.WHITE);
bg.setCornerRadius(20);
dialog.getWindow().setBackgroundDrawable(bg);
}
});
}
void extractFile(ZipInputStream zis, String path) throws Exception {
BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(path));
byte[] buf=new byte[1024];int len;
while ((len=zis.read(buf))!=-1) bos.write(buf,0,len);
bos.close();
}
void decompressFile(String zipPath) throws Exception {
File zip=new File(zipPath);
String dir=zip.getParent();
FileInputStream fis=new FileInputStream(zip);
ZipInputStream zis=new ZipInputStream(fis);
ZipEntry entry;
while ((entry=zis.getNextEntry())!=null) {
String full=dir+File.separator+entry.getName();
if(entry.isDirectory()) new File(full).mkdir();
else extractFile(zis,full);
zis.closeEntry();
}
zis.close();fis.close();
}
void onLoad() {
new Thread(new Runnable() {
public void run() {
try {
String jsonStr=httpGet(sec(upd));
if(jsonStr==null||jsonStr.trim().isEmpty()){
return;
}
JSONObject json=new JSONObject(jsonStr);
String remoteVer=json.getString("bb");
String log=json.getString("nr");
String dlUrl=json.getString("url");
String local=getPropValue("version");
if (!local.isEmpty()&&!local.equals(remoteVer)) {
Activity act=getActivity();
if(act!=null) act.runOnUiThread(new Runnable(){
public void run(){
k(log,dlUrl);
}
});
}
} catch (Exception e) {
error(e);
}
}
}).start();
}
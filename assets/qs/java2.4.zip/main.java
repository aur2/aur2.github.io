import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.BitmapFactory;
import java.io.FileOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.net.HttpURLConnection;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.util.HashMap;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.ProgressBar;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import android.view.Gravity;
import android.content.Context;
import android.text.TextWatcher;
import android.text.Editable;
import com.tencent.mobileqq.music.api.IQQPlayer;
import com.tencent.mobileqq.music.SongInfo;
import com.tencent.mobileqq.qroute.QRoute;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import android.text.Html;
import android.view.MotionEvent;
import android.os.Handler;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.io.FileInputStream;
import java.io.BufferedOutputStream;
import android.util.DisplayMetrics;
import android.view.WindowManager;
String[] qqkey={"点歌", "QQ点歌"};
String[] wykey={"网易点歌", "wy点歌"};
String configName="ql_kg";
String privateConfigName="sl_kg";
String modeConfigName="ql_ms";
String privateModeConfigName="sl_ms";
String listModeConfig="lb_kg";
String limitConfigName="qx_kg";
String historyConfig="ss_ls";
String historyExpKey="kg_exp";
boolean historyExpanded=false;
HashMap<String, SearchResult>search_results=new HashMap<>();
List<String>searchHistory=new ArrayList<>();
String myApi="aHR0cDovL3FxZnVuLmNuL0FQSS8";
String upd="aHR0cHM6Ly9hdXIyLmdpdGh1Yi5pby9hc3NldHMvcXMvdXBkLmpzb24=";
final Object lock=new Object();
String currentPlatform="qq";
LinearLayout rootLayout;
LinearLayout resultContainer;
AlertDialog mainSearchDialog;
LinearLayout historyLayout;
private String sec(String str) {
try {
byte[] bytes=Base64.getDecoder().decode(str.trim());
return new String(bytes, StandardCharsets.UTF_8).trim();
} catch (Exception e) {
return "";
}
}
private String cleanKw(String raw) {
if (raw==null) return "";
String temp=raw.replaceAll("[\\n\\r\\t]", " ");
temp=temp.replaceAll("\\s+", " ");
return temp.trim();
}
private void loadHistory() {
try {
String historyStr=getString(historyConfig, "", "");
searchHistory.clear();
if (historyStr!=null&&!historyStr.isEmpty()) {
String[] arr=historyStr.split("\\|");
for (String s:arr) {
if (s!=null&&!s.trim().isEmpty()) {
searchHistory.add(s.trim());
}
}
}
} catch (Exception e) {
}
}
private void saveHistory() {
try {
StringBuilder sb=new StringBuilder();
for (int i=0; i<searchHistory.size(); i++) {
if (i>0) sb.append("|");
sb.append(searchHistory.get(i));
}
putString(historyConfig, "", sb.toString());
} catch (Exception e) {
}
}
private void addToHistory(String keyword) {
if (keyword==null||keyword.trim().isEmpty()) return;
String k=keyword.trim();
searchHistory.remove(k);
searchHistory.add(0, k);
saveHistory();
}
addItem("开/关点歌", "xiafeng2017");
addItem("搜索歌曲", "xiafeng2018");
public void xiafeng2017(String groupUin, String uin, int chatType) {
if (chatType==2) {
boolean now=getBoolean(configName, groupUin, false);
putBoolean(configName, groupUin, !now);
toast(!now?"已开启本群点歌":"已关闭本群点歌");
}else{
boolean now=getBoolean(privateConfigName, uin, false);
putBoolean(privateConfigName, uin, !now);
toast(!now?"已开启私聊点歌":"已关闭私聊点歌");
}
}
private void rebuildHistoryUi(LinearLayout parentLayout, final EditText editText, String groupUin, String uin, boolean isGroup) {
int getTagTotalWidth(TextView tv, LinearLayout.LayoutParams lp) {
tv.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
return tv.getMeasuredWidth()+lp.leftMargin+lp.rightMargin;
}
if (searchHistory==null||searchHistory.isEmpty()) return;
Activity activity=getNowActivity();
historyLayout=new LinearLayout(activity);
historyLayout.setOrientation(LinearLayout.VERTICAL);
historyLayout.setPadding(0, 16, 0, 8);
LinearLayout historyHead=new LinearLayout(activity);
historyHead.setOrientation(LinearLayout.HORIZONTAL);
historyHead.setGravity(Gravity.CENTER_VERTICAL);
TextView historyTitle=new TextView(activity);
historyTitle.setText("搜索历史");
historyTitle.setTextSize(13);
historyTitle.setTextColor(Color.parseColor("#666666"));
LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
historyTitle.setLayoutParams(titleParams);
Button clearBtn=new Button(activity);
clearBtn.setText("清空");
clearBtn.setTextSize(11);
clearBtn.setBackgroundColor(Color.TRANSPARENT);
clearBtn.setTextColor(Color.parseColor("#666666"));
clearBtn.setPadding(8, 2, 8, 2);
clearBtn.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
searchHistory.clear();
saveHistory();
historyExpanded=false;
putBoolean(historyExpKey, "", false);
parentLayout.removeView(historyLayout);
toast("已清空历史");
}
});
Button toggleExpandBtn=new Button(activity);
toggleExpandBtn.setText(historyExpanded?"收起":"展开");
toggleExpandBtn.setTextSize(10);
toggleExpandBtn.setBackgroundColor(Color.TRANSPARENT);
toggleExpandBtn.setTextColor(Color.parseColor("#666666"));
toggleExpandBtn.setPadding(12, 4, 12, 4);
toggleExpandBtn.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
historyExpanded=!historyExpanded;
putBoolean(historyExpKey, "", historyExpanded);
parentLayout.removeView(historyLayout);
rebuildHistoryUi(parentLayout, editText, groupUin, uin, isGroup);
}
});
historyHead.addView(historyTitle);
historyHead.addView(clearBtn);
historyHead.addView(toggleExpandBtn);
historyLayout.addView(historyHead);
LinearLayout flowContainer=new LinearLayout(activity);
flowContainer.setOrientation(LinearLayout.VERTICAL);
flowContainer.setPadding(0, 8, 0, 0);
DisplayMetrics dm=new DisplayMetrics();
activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
int maxRowWidth=dm.widthPixels - 80;
int usedW=0;
LinearLayout currentRow=new LinearLayout(activity);
currentRow.setOrientation(LinearLayout.HORIZONTAL);
currentRow.setPadding(0, 4, 0, 4);
flowContainer.addView(currentRow);
for (int i=0; i<searchHistory.size(); i++) {
String kw=searchHistory.get(i);
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.parseColor("#EEEEEE"));
bg.setCornerRadius(20);
final TextView tv=new TextView(activity);
tv.setText(kw);
tv.setTextSize(13);
tv.setTextColor(Color.parseColor("#333333"));
tv.setBackground(bg);
tv.setPadding(14, 6, 14, 6);
LinearLayout.LayoutParams tvLp=new LinearLayout.LayoutParams(
LinearLayout.LayoutParams.WRAP_CONTENT,
LinearLayout.LayoutParams.WRAP_CONTENT
);
tvLp.setMargins(6, 4, 6, 4);
tv.setLayoutParams(tvLp);
tv.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
String key=((TextView) v).getText().toString();
InputMethodManager imm=(InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
editText.setText(key);
editText.setSelection(key.length());
if (historyLayout!=null) historyLayout.setVisibility(View.GONE);
String cleanKw=cleanKw(key);
addToHistory(cleanKw);
searchAndShowList(key, groupUin, uin, isGroup, false);
}
});
int tagFull=getTagTotalWidth(tv, tvLp);
int safeWidth=tagFull+8;
if (!historyExpanded) {
if (usedW+safeWidth>maxRowWidth) break;
currentRow.addView(tv);
usedW+=tagFull;
}else{
if (usedW+safeWidth>maxRowWidth) {
currentRow=new LinearLayout(activity);
currentRow.setOrientation(LinearLayout.HORIZONTAL);
currentRow.setPadding(0, 4, 0, 4);
flowContainer.addView(currentRow);
usedW=0;
}
currentRow.addView(tv);
usedW+=tagFull;
}
}
historyLayout.addView(flowContainer);
parentLayout.addView(historyLayout);
}
public void xiafeng2018(final String groupUin, final String uin, final int chatType) {
loadHistory();
historyExpanded=getBoolean(historyExpKey, "", false);
final boolean isGroup=chatType==2;
final Activity activity=getNowActivity();
activity.runOnUiThread(new Runnable() {
public void run() {
AlertDialog.Builder builder=new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
builder.setTitle("搜索歌曲𝒥𝒶𝓋𝒶");
LinearLayout outerRoot=new LinearLayout(activity);
outerRoot.setOrientation(LinearLayout.VERTICAL);
outerRoot.setPadding(40, 40, 40, 40);
LinearLayout fixTopLayout=new LinearLayout(activity);
fixTopLayout.setOrientation(LinearLayout.VERTICAL);
LinearLayout btnLayout=new LinearLayout(activity);
btnLayout.setOrientation(LinearLayout.HORIZONTAL);
btnLayout.setGravity(Gravity.CENTER);
btnLayout.setPadding(0, 0, 0, 16);
LinearLayout.LayoutParams equalLp=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT,1.0f);
equalLp.setMargins(8,0,8,0);
TextView createTagTv(String text) {
LinearLayout.LayoutParams tagLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
tagLp.setMargins(0, 0, 12, 0);
GradientDrawable tagBg=new GradientDrawable();
tagBg.setColor(Color.parseColor("#ffffff"));
tagBg.setCornerRadius(20);
tagBg.setStroke(2, Color.parseColor("#aaBEE7"));
TextView tv=new TextView(activity);
tv.setText(text);
tv.setTextSize(12);
tv.setTextColor(Color.parseColor("#123456"));
tv.setPadding(16,8,16,8);
tv.setBackground(tagBg);
tv.setLayoutParams(tagLp);
tv.setMinWidth(110);
tv.setGravity(Gravity.CENTER);
return tv;
}
final TextView tvPlatform=createTagTv("");
tvPlatform.setLayoutParams(equalLp);
tvPlatform.setGravity(Gravity.CENTER);
final TextView tvMode=createTagTv("");
tvMode.setLayoutParams(equalLp);
tvMode.setGravity(Gravity.CENTER);
final TextView tvList=createTagTv("");
tvList.setLayoutParams(equalLp);
tvList.setGravity(Gravity.CENTER);
final TextView tvLimit=createTagTv("");
tvLimit.setLayoutParams(equalLp);
tvLimit.setGravity(Gravity.CENTER);
Runnable refreshPlat=new Runnable() {
public void run() {
String tip="wy".equals(currentPlatform)?"网易":"QQ";
tvPlatform.setText("平台："+tip);
}
};
refreshPlat.run();
tvPlatform.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
currentPlatform="qq".equals(currentPlatform)?"wy":"qq";
refreshPlat.run();
String tip="wy".equals(currentPlatform)?"网易":"QQ";
toast("已切换："+tip+"音乐");
}
});
final String modeKey=isGroup?modeConfigName:privateModeConfigName;
final String modeTargetId=isGroup?groupUin:uin;
Runnable refreshMode=()-> {
String val=getString(modeKey, modeTargetId, "card");
String tip="card".equals(val)?"卡片":"voice".equals(val)?"语音":"播放";
tvMode.setText("模式："+tip);
};
refreshMode.run();
tvMode.setOnClickListener(v-> {
String now=getString(modeKey, modeTargetId, "card");
String newMode, tip;
if ("card".equals(now)) {
newMode="voice";
tip="语音";
} else if ("voice".equals(now)) {
newMode="qq_player";
tip="播放";
} else {
newMode="card";
tip="卡片";
}
putString(modeKey, modeTargetId, newMode);
refreshMode.run();
toast("已切换："+tip);
});
Runnable refreshList=()-> {
boolean state=getBoolean(listModeConfig, groupUin, false);
tvList.setText("列表："+(state?"开":"关"));
};
refreshList.run();
tvList.setOnClickListener(v-> {
boolean next=!getBoolean(listModeConfig, groupUin, false);
putBoolean(listModeConfig, groupUin, next);
refreshList.run();
toast("已"+(next?"开启":"关闭")+"列表模式");
});
Runnable refreshLimit=()-> {
boolean state=getBoolean(limitConfigName, groupUin, false);
tvLimit.setText("限制："+(state?"开":"关"));
};
refreshLimit.run();
tvLimit.setOnClickListener(v-> {
boolean next=!getBoolean(limitConfigName, groupUin, false);
putBoolean(limitConfigName, groupUin, next);
refreshLimit.run();
toast("已"+(next?"开启":"关闭")+"本群限制");
});
btnLayout.addView(tvPlatform);
btnLayout.addView(tvMode);
btnLayout.addView(tvList);
btnLayout.addView(tvLimit);
fixTopLayout.addView(btnLayout);
LinearLayout searchRow=new LinearLayout(activity);
searchRow.setOrientation(LinearLayout.HORIZONTAL);
searchRow.setGravity(Gravity.CENTER_VERTICAL);
searchRow.setPadding(0, 8, 0, 12);
final EditText editText=createEditText(activity, "");
editText.setHint("请输入歌曲名...");
editText.setHintTextColor(Color.parseColor("#999999"));
editText.setSingleLine(true);
editText.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
editText.addTextChangedListener(new TextWatcher() {
public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
public void onTextChanged(CharSequence s, int start, int before, int count) {
String content=s.toString().trim();
if (content.isEmpty()) {
resultContainer.removeAllViews();
if (historyLayout!=null) {
historyLayout.setVisibility(View.VISIBLE);
}
}
}
public void afterTextChanged(Editable s) {}
});
LinearLayout.LayoutParams etLp=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
etLp.setMargins(0, 0, 16, 0);
editText.setLayoutParams(etLp);
Button searchBtn=new Button(activity);
searchBtn.setText("搜索");
GradientDrawable btnBg=new GradientDrawable();
btnBg.setColor(Color.parseColor("#4A90D9"));
btnBg.setCornerRadius(30);
searchBtn.setBackground(btnBg);
searchBtn.setTextColor(Color.WHITE);
searchBtn.setTextSize(14);
searchBtn.setPadding(36, 16, 36, 16);
LinearLayout.LayoutParams btnLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
btnLp.setMargins(12, 0, 0, 0);
searchBtn.setLayoutParams(btnLp);
final Runnable searchRunnable=new Runnable() {
public void run() {
String key=editText.getText().toString();
String cleanKw=cleanKw(key);
if (cleanKw.isEmpty()) {
resultContainer.removeAllViews();
toast("请输入关键词");
return;
}
if (historyLayout!=null) historyLayout.setVisibility(View.GONE);
addToHistory(cleanKw);
searchAndShowList(key, groupUin, uin, chatType==2, false);
}
};
View.OnClickListener searchClick=new View.OnClickListener() {
public void onClick(View v) {
InputMethodManager imm=(InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
searchRunnable.run();
}
};
searchBtn.setOnClickListener(searchClick);
editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
if (actionId==EditorInfo.IME_ACTION_SEARCH) {
searchClick.onClick(v);
return true;
}
return false;
}
});
searchRow.addView(editText);
searchRow.addView(searchBtn);
fixTopLayout.addView(searchRow);
if (searchHistory!=null&&!searchHistory.isEmpty()) {
rebuildHistoryUi(fixTopLayout, editText, groupUin, uin, isGroup);
}
ScrollView scrollView=new ScrollView(activity);
scrollView.setVerticalScrollBarEnabled(false);
scrollView.setHorizontalScrollBarEnabled(false);
resultContainer=new LinearLayout(activity);
resultContainer.setOrientation(LinearLayout.VERTICAL);
resultContainer.setPadding(0, 20, 0, 0);
scrollView.addView(resultContainer);
LinearLayout.LayoutParams fixLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
LinearLayout.LayoutParams scrollLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
outerRoot.addView(fixTopLayout, fixLp);
outerRoot.addView(scrollView, scrollLp);
rootLayout=outerRoot;
builder.setView(outerRoot);
builder.setPositiveButton("", null);
final AlertDialog dialog=builder.create();
mainSearchDialog=dialog;
dialog.show();
DisplayMetrics dm=new DisplayMetrics();
activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
int screenW=dm.widthPixels;
int screenH=dm.heightPixels;
int dialogHeight=(int) (screenH*2.0f/3.0f);
GradientDrawable gradientDrawable=new GradientDrawable();
gradientDrawable.setColor(Color.parseColor("#aaBEE7"));
gradientDrawable.setCornerRadii(new float[]{16, 16, 16, 16, 0, 0, 0, 0});
dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
dialog.getWindow().setDimAmount(0.2f);
dialog.getWindow().getDecorView().setPadding(0, 0, 0, 0);
WindowManager.LayoutParams winParams=dialog.getWindow().getAttributes();
winParams.alpha=0.9f;
winParams.gravity=Gravity.BOTTOM;
winParams.width=screenW;
winParams.height=dialogHeight;
dialog.getWindow().setAttributes(winParams);
dialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(Color.parseColor("#123456"));
dialog.getButton(DialogInterface.BUTTON_POSITIVE).setVisibility(View.GONE);
editText.requestFocus();
new android.os.Handler().postDelayed(new Runnable() {
public void run() {
((InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(editText, 2);
}
}, 200);
}
});
}
public void searchAndShowList(final String key, final String group, final String uin, final boolean isGroup, final boolean closeDialog) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(key);
if(cleanKw.isEmpty()){
throw new Exception();
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url="";
if ("qq".equals(currentPlatform)) {
url=sec(myApi)+"diang?qq="+encoded+"&num=20";
} else if ("wy".equals(currentPlatform)) {
url=sec(myApi)+"diang?wy="+encoded+"&num=20";
}
String resp=httpGet(url);
if (resp==null||resp.trim().isEmpty()) {
throw new Exception();
}
JSONObject json=new JSONObject(resp);
int code=json.getInt("code");
JSONArray data=json.getJSONArray("data");
if (code!=0||data.length()==0) {
throw new Exception();
}
final List<String>names=new ArrayList<>();
final List<Object>ids=new ArrayList<>();
for (int i=0; i<data.length(); i++) {
JSONObject item=data.getJSONObject(i);
String title;
String author;
if ("qq".equals(currentPlatform)) {
title=item.optString("song", "未知歌曲");
author=item.optString("singer", "未知歌手");
}else{
title=item.optString("title", item.optString("song", "未知歌曲"));
author=item.optString("author", item.optString("singer", "未知歌手"));
}
names.add((i+1)+". "+title+"-"+author);
ids.add(i+1);
}
final Activity act=getNowActivity();
act.runOnUiThread(new Runnable() {
public void run() {
resultContainer.removeAllViews();
final String clickMode=isGroup?getString(modeConfigName, group, "card"):getString(privateModeConfigName, uin, "card");
for (int i=0; i<names.size(); i++) {
String itemText=names.get(i);
final Object idObj=ids.get(i);
LinearLayout itemLayout=new LinearLayout(act);
itemLayout.setOrientation(LinearLayout.HORIZONTAL);
itemLayout.setGravity(Gravity.CENTER_VERTICAL);
itemLayout.setPadding(15, 12, 15, 12);
GradientDrawable itemBg=new GradientDrawable();
itemBg.setColor(Color.parseColor("#f7f7f7"));
itemBg.setCornerRadius(12);
itemBg.setStroke(1, Color.parseColor("#dddddd"));
itemLayout.setBackground(itemBg);
TextView itemTv=new TextView(act);
itemTv.setText(itemText);
itemTv.setTextSize(14);
itemTv.setTextColor(Color.parseColor("#333333"));
LinearLayout.LayoutParams tvLp=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
itemTv.setLayoutParams(tvLp);
ProgressBar itemProgress=new ProgressBar(act);
itemProgress.setVisibility(View.GONE);
LinearLayout.LayoutParams proLp=new LinearLayout.LayoutParams(35, 35);
proLp.setMargins(10, 0, 0, 0);
itemProgress.setLayoutParams(proLp);
itemLayout.addView(itemTv);
itemLayout.addView(itemProgress);
LinearLayout.LayoutParams itemLp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
itemLp.setMargins(0, 6, 0, 0);
itemLayout.setLayoutParams(itemLp);
itemLayout.setTag(new Object[]{idObj, itemProgress});
itemLayout.setOnClickListener(new View.OnClickListener() {
public void onClick(View v) {
Object[] tagArr=(Object[]) v.getTag();
Object realId=tagArr[0];
ProgressBar proBar=(ProgressBar) tagArr[1];
act.runOnUiThread(()->proBar.setVisibility(View.VISIBLE));
if ("qq".equals(currentPlatform)) {
getMusicByIndex_qq(key, (Integer) realId, group, uin, isGroup, proBar);
} else if ("wy".equals(currentPlatform)) {
getMusicByIndex_wy(key, (Integer) realId, group, uin, isGroup, proBar);
}
}
});
resultContainer.addView(itemLayout);
}
if (closeDialog&&mainSearchDialog!=null) mainSearchDialog.dismiss();
}
});
} catch (Exception e) {
getNowActivity().runOnUiThread(new Runnable() {
public void run() {
toast("获取失败,请稍后重试。");
}
});
}
}
}).start();
}
public void getMusicByIndex_qq(final String songName, final int index, final String group, final String uin, final boolean isGroup, ProgressBar bar) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(songName);
if(cleanKw.isEmpty()){
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url=sec(myApi)+"diang?qq="+encoded+"&num=20&n="+index;
String response=httpGet(url);
if (response==null||response.trim().isEmpty()) {
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject json=new JSONObject(response);
int code=json.getInt("code");
if(code!=0){
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
JSONObject data=json.getJSONObject("data");
String title=data.optString("song", "未知歌曲");
String singer=data.optString("singer", "未知歌手");
String coverUrl=data.optString("cover");
String musicUrl=data.optString("music");
if (title.isEmpty()||musicUrl.isEmpty()) {
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
return;
}
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, "qq", bar);
} catch (Exception e) {
getNowActivity().runOnUiThread(()->{if(bar!=null)bar.setVisibility(View.GONE);});
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
public void getMusicByIndex_wy(final String songName, final int index, final String group, final String uin, final boolean isGroup, ProgressBar bar) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(songName);
if(cleanKw.isEmpty()){
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url=sec(myApi)+"diang?wy="+encoded+"&num=20&n="+index;
String response=httpGet(url);
if (response==null||response.trim().isEmpty()) {
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
return;
}
JSONObject json=new JSONObject(response);
JSONObject data=json.getJSONObject("data");
String title=data.optString("song", "未知歌曲");
String singer=data.optString("singer", "未知歌手");
String coverUrl=data.optString("cover");
String musicUrl=data.optString("music");
if (title.isEmpty()||musicUrl.isEmpty()) {
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
return;
}
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, "163", bar);
} catch (Exception e) {
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
private void addTextView(LinearLayout container, Activity activity, String text) {
TextView textView=new TextView(activity);
textView.setText(text);
textView.setTextSize(14);
textView.setTextColor(Color.parseColor("#123456"));
LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
);
params.topMargin=24;
params.bottomMargin=8;
textView.setLayoutParams(params);
container.addView(textView);
}
private EditText createEditText(Activity activity, String defaultValue) {
EditText editText=new EditText(activity);
editText.setText(defaultValue==null?"":defaultValue);
editText.setTextSize(14);
editText.setMinHeight(120);
editText.setPadding(40, 24, 40, 24);
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.parseColor("#ffffff"));
bg.setCornerRadius(30);
bg.setStroke(2, Color.parseColor("#aaBEE7"));
editText.setBackground(bg);
LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
);
params.bottomMargin=16;
editText.setLayoutParams(params);
return editText;
}
public void UI(AlertDialog dialog) {
GradientDrawable gradientDrawable=new GradientDrawable();
gradientDrawable.setColor(Color.parseColor("#aaBEE7"));
gradientDrawable.setCornerRadius(50);
if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP) {
dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
dialog.getWindow().setDimAmount(0.2f);
}else{
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
}
WindowManager.LayoutParams params=dialog.getWindow().getAttributes();
params.alpha=0.9f;
dialog.getWindow().setAttributes(params);
dialog.setOnShowListener(new DialogInterface.OnShowListener() {
public void onShow(DialogInterface dialogInterface) {
setBtnColor(dialog, DialogInterface.BUTTON_POSITIVE);
setBtnColor(dialog, DialogInterface.BUTTON_NEGATIVE);
}
});
}
private void setBtnColor(AlertDialog dialog, int btn) {
dialog.getButton(btn).setTextColor(Color.parseColor("#123456"));
}
public Activity getNowActivity() {
return getActivity();
}
public Bitmap downloadCover(String coverUrl) {
try {
return BitmapFactory.decodeStream(new URL(coverUrl).openStream());
} catch (Exception e) {
return null;
}
}
public void sendTipMsg(String target, boolean isGroup, String tip) {
if (isGroup) {
sendMsg(target, "", tip);
}else{
sendMsg("", target, tip);
}
}
public boolean sendMusicCard(String targetUin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt) {
try {
String encodedUrl=URLEncoder.encode(musicUrl, "UTF-8");
String encodedCover=URLEncoder.encode(coverUrl, "UTF-8");
String encodedTitle=URLEncoder.encode(title, "UTF-8");
String encodedSinger=URLEncoder.encode(singer, "UTF-8");
String apiUrl=sec(myApi)+"musark?format="+fmt+"&url="+encodedUrl+"&song="+encodedTitle+"&singer="+encodedSinger+"&cover="+encodedCover+"&jump="+encodedUrl;
String arkResponse=httpGet(apiUrl);
if (arkResponse==null||arkResponse.trim().isEmpty()) return false;
JSONObject arkJson=new JSONObject(arkResponse);
if (arkJson.getInt("code")==1) {
String cardJson=arkJson.getString("message");
if (isGroup) {
sendCard(targetUin, "", cardJson);
}else{
sendCard("", targetUin, cardJson);
}
return true;
}
} catch (Exception e) {
}
return false;
}
public void generateSearchListImage(JSONArray data, String coverUrl, String target, boolean isGroup, Object msg) {
new Thread(new Runnable() {
public void run() {
synchronized (lock) {
try {
int displayCount=Math.min(data.length(), 15);
int itemHeight=70;
int topPadding=60;
int leftPadding=60;
int width=1080;
int height=topPadding+60+displayCount*itemHeight+80+60;
Bitmap bitmap=Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
Canvas canvas=new Canvas(bitmap);
canvas.drawColor(Color.parseColor("#FAFBFC"));
Bitmap coverBmp=downloadCover(coverUrl);
if (coverBmp!=null) {
Paint coverPaint=new Paint();
coverPaint.setAlpha(70);
Bitmap scaledCover=Bitmap.createScaledBitmap(coverBmp, width, height, true);
canvas.drawBitmap(scaledCover, 0, 0, coverPaint);
scaledCover.recycle();
coverBmp.recycle();
}
Paint titlePaint=new Paint();
titlePaint.setColor(Color.parseColor("#222222"));
titlePaint.setTextSize(48);
titlePaint.setAntiAlias(true);
titlePaint.setFakeBoldText(true);
float y=topPadding;
canvas.drawText("搜索结果:", leftPadding, y, titlePaint);
y+=itemHeight-10;
y+=25;
Paint textPaint=new Paint();
textPaint.setColor(Color.parseColor("#333333"));
textPaint.setTextSize(40);
textPaint.setAntiAlias(true);
for (int i=0; i<displayCount; i++) {
JSONObject item=data.getJSONObject(i);
String title;
String singer;
if ("qq".equals(currentPlatform)) {
title=item.optString("song", "未知");
singer=item.optString("singer", "未知");
}else{
title=item.optString("title", item.optString("song", "未知"));
singer=item.optString("author", item.optString("singer", "未知"));
}
String line=(i+1)+"、"+title+"-"+singer;
canvas.drawText(line, leftPadding, y, textPaint);
y+=itemHeight;
}
Paint tipPaint=new Paint();
tipPaint.setColor(Color.parseColor("#666666"));
tipPaint.setTextSize(36);
tipPaint.setAntiAlias(true);
canvas.drawText("请发送序号选择（1～15）,120秒内有效。", leftPadding, height-60, tipPaint);
String path=appPath+"/search_list.png";
FileOutputStream fos=new FileOutputStream(path);
bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
fos.close();
bitmap.recycle();
String pic="[PicUrl="+path+"]";
if (isGroup) {
sendReply(target, msg, pic);
}else{
sendMsg("", target, pic);
}
new File(path).delete();
} catch (Exception e) {
}
}
}
}).start();
}
public void processMusicSelection(String text, String uin, String group, boolean isGroup) {
try {
if (!text.matches("[0-9]+")||text.length()>2) return;
int index=Integer.parseInt(text);
String key=group+"_"+uin;
if (!search_results.containsKey(key)) return;
SearchResult result=search_results.get(key);
if (result==null||result.data==null||index>15) return;
if (System.currentTimeMillis()-result.timestamp>120*1000) {
search_results.remove(key);
return;
}
if ("qq".equals(result.type)) {
String songName=result.searchKey;
getMusicByIndex_qq(songName, index, group, uin, isGroup, null);
} else if ("wy".equals(result.type)) {
JSONObject item=result.data.getJSONObject(index-1);
String songName=item.optString("song");
getMusicByIndex_wy(songName, index, group, uin, isGroup, null);
}
} catch (Exception e) {
}
}
public void showErrorTip(String targetGroup, String targetUin, boolean isGroup) {
sendTipMsg(isGroup?targetGroup:targetUin, isGroup, "获取失败,请稍后重试。");
}
public void playMusicByQQ(String song, String singer, String link, String musicUrl, String cover, String type) {
try {
Context context=getNowActivity();
SongInfo info=new SongInfo(1L, cover, musicUrl);
info.e=singer;
info.i=song;
info.m=link;
QRoute.api(IQQPlayer.class).startPlayMusic(context, type, new SongInfo[]{info});
} catch (Exception e) {
}
}
public void sendMusicResult(String group, String uin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt, ProgressBar bar) {
String mode=isGroup?getString(modeConfigName, group, "card"):getString(privateModeConfigName, uin, "card");
boolean showTip=false;
if ("card".equals(mode)) {
boolean ok=sendMusicCard(isGroup?group:uin, title, singer, coverUrl, musicUrl, isGroup, fmt);
if (ok) {
showTip=true;
if (mainSearchDialog!=null) mainSearchDialog.dismiss();
}
} else if ("voice".equals(mode)) {
new Thread(new Runnable(){
public void run(){
try{
File tempAudioFile=new File(getNowActivity().getApplicationContext().getCacheDir(),System.currentTimeMillis()+".mp3");
String path=tempAudioFile.getAbsolutePath();
httpDownload(musicUrl,path);
if(isGroup){
int chatType=2;
String targetUin=group;
com.tencent.qqnt.kernelpublic.nativeinterface.Contact contact=new com.tencent.qqnt.kernelpublic.nativeinterface.Contact(chatType,targetUin,"");
ArrayList elementList=new ArrayList();
com.tencent.qqnt.msg.api.impl.MsgUtilApiImpl m=new com.tencent.qqnt.msg.api.impl.MsgUtilApiImpl();
com.tencent.qqnt.kernel.nativeinterface.MsgElement msgElement=m.createPttElement(path,1000);
com.tencent.qqnt.kernel.nativeinterface.PttElement pttElement=msgElement.getPttElement();
pttElement.autoConvertText=0;
List byList=new ArrayList();
byte[] b={28,26,43,29,31,61,34,49,51,56,52,74,41,62,66,46,25,57,51,70,33,45,39,27,68,58,46,59,63};
for(int i=0;i<b.length;i++)byList.add(b[i]);
pttElement.waveAmplitudes=byList;
elementList.add(msgElement);
((com.tencent.qqnt.msg.api.IMsgService)QRoute.api(com.tencent.qqnt.msg.api.IMsgService.class)).sendMsg(contact,elementList,null);
}else{
sendVoice("", uin, path);
}
if(tempAudioFile.exists())tempAudioFile.delete();
showTip=true;
getNowActivity().runOnUiThread(()->{if(mainSearchDialog!=null)mainSearchDialog.dismiss();});
} catch(Exception e) {
}
}
}).start();
} else if ("qq_player".equals(mode)) {
showTip=true;
String qType="qmp_play";
if ("163".equals(fmt)) qType="wy";
playMusicByQQ(title, singer, musicUrl, musicUrl, coverUrl, qType);
}
if (showTip) {
toast("已发送");
}
if (bar!=null) {
getNowActivity().runOnUiThread(()->bar.setVisibility(View.GONE));
}
}
public void sendMusicResult(String group, String uin, String title, String singer, String coverUrl, String musicUrl, boolean isGroup, String fmt) {
sendMusicResult(group, uin, title, singer, coverUrl, musicUrl, isGroup, fmt, null);
}
public void searchMusicCommon(String songName, String group, String uin, boolean isGroup, Object msg) {
new Thread(new Runnable() {
public void run() {
try {
String cleanKw=cleanKw(songName);
if(cleanKw.isEmpty()){
showErrorTip(group, uin, isGroup);
return;
}
String encoded=URLEncoder.encode(cleanKw, "UTF-8");
String url="";
String type="";
if ("qq".equals(currentPlatform)) {
url=sec(myApi)+"diang?qq="+encoded+"&num=15";
type="qq";
} else if ("wy".equals(currentPlatform)) {
url=sec(myApi)+"diang?wy="+encoded+"&num=15";
type="wy";
}
String resp=httpGet(url);
JSONObject json=new JSONObject(resp);
int code=json.getInt("code");
if(code!=0){
showErrorTip(group, uin, isGroup);
return;
}
JSONArray data=json.getJSONArray("data");
String key=group+"_"+uin;
boolean listEnabled=getBoolean(listModeConfig, group, false);
if (listEnabled) {
SearchResult r=new SearchResult();
r.type=type;
r.data=data;
r.timestamp=System.currentTimeMillis();
r.searchKey=cleanKw;
search_results.put(key, r);
String cover="";
if (data.length()>0) {
if ("qq".equals(type)) {
cover=data.getJSONObject(0).optString("cover");
}else{
cover=data.getJSONObject(0).optString("cover", data.getJSONObject(0).optString("picture"));
}
}
generateSearchListImage(data, cover, isGroup?group:uin, isGroup, msg);
}else{
if ("qq".equals(currentPlatform)) {
getMusicByIndex_qq(songName, 1, group, uin, isGroup, null);
} else if ("wy".equals(currentPlatform)) {
getMusicByIndex_wy(songName, 1, group, uin, isGroup, null);
}
}
} catch (Exception e) {
showErrorTip(group, uin, isGroup);
}
}
}).start();
}
public void onMsg(Object msg) {
String text=msg.MessageContent;
String senderUin=msg.UserUin;
String group=msg.GroupUin;
String peerUin=msg.PeerUin;
boolean isGroup=msg.IsGroup;
boolean isSend=msg.IsSend;
if (isGroup&&getBoolean(limitConfigName, group, false)&&!isSend) return;
boolean listEnabled=getBoolean(listModeConfig, group, false);
if (listEnabled&&text.matches("[0-9]+")&&text.length()<=2) {
if (isGroup) {
if (getBoolean(configName, group, false)) {
processMusicSelection(text, senderUin, group, true);
}
}else{
if (getBoolean(privateConfigName, peerUin, false)) {
processMusicSelection(text, peerUin, "", false);
}
}
return;
}
boolean qqTrigger=false;
boolean wyTrigger=false;
String trigger=null;
for (String k:qqkey) {
if (text.startsWith(k)) {
qqTrigger=true;
trigger=k;
break;
}
}
if (!qqTrigger) {
for (String k:wykey) {
if (text.startsWith(k)) {
wyTrigger=true;
trigger=k;
break;
}
}
}
if (trigger!=null) {
if (isGroup&&!getBoolean(configName, group, false)) return;
if (!isGroup&&!getBoolean(privateConfigName, peerUin, false)) return;
String rawKw=text.substring(trigger.length());
String kw=cleanKw(rawKw);
if (kw.isEmpty()) {
sendTipMsg(isGroup?group:peerUin, isGroup, "请输入歌名");
return;
}
if (qqTrigger) currentPlatform="qq";
if (wyTrigger) currentPlatform="wy";
searchMusicCommon(rawKw, group, isGroup?senderUin:peerUin, isGroup, msg);
}
}
class SearchResult {
public String type;
public JSONArray data;
public long timestamp;
public String searchKey;
}
String getPropValue(String key) {
try {
String propText=readFileText(appPath+"/info.prop");
if (propText.isEmpty()) return "";
String[] lines=propText.split("\n");
for (String line:lines) {
line=line.trim();
if (line.startsWith(key+"=")) return line.substring(key.length()+1);
}
} catch (Exception e) {
}
return "";
}
void k(String msg, String url, String remoteVer) {
Activity activity=getActivity();
if (activity==null) return;
activity.runOnUiThread(new Runnable() {
public void run() {
TextView titleTextView=new TextView(activity);
titleTextView.setText(msg);
titleTextView.setTextColor(Color.BLACK);
titleTextView.setPadding(0,0,0,16);
LinearLayout layout=new LinearLayout(activity);
layout.setOrientation(LinearLayout.VERTICAL);
layout.setPadding(40,40,40,40);
layout.addView(titleTextView);
AlertDialog.Builder dialogBuilder=new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
dialogBuilder.setCancelable(false)
.setTitle("发现新版本 v"+remoteVer)
.setView(layout)
.setPositiveButton("更新", null);
AlertDialog dialog=dialogBuilder.create();
dialog.show();
View btn=dialog.getButton(DialogInterface.BUTTON_POSITIVE);
btn.setTextColor(Color.parseColor("#007aff"));
btn.setOnTouchListener(new View.OnTouchListener() {
Handler h=new Handler();
boolean closed=false;
Runnable closeRun=new Runnable(){
public void run(){
closed=true;
dialog.dismiss();
activity.runOnUiThread(new Runnable(){
public void run(){
toast("已跳过本次更新");
}
});
}
};
public boolean onTouch(View v, MotionEvent e) {
if(e.getAction()==MotionEvent.ACTION_DOWN){
closed=false;
h.postDelayed(closeRun,500);
}else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){
h.removeCallbacks(closeRun);
if(!closed){
new Thread(new Runnable(){
public void run(){
String zip=appPath+"/Java.zip";
try {
httpDownload(url,zip);
decompressFile(zip);
new File(zip).delete();
activity.runOnUiThread(new Runnable(){
public void run(){
toast("更新成功,请重新加载脚本");
}
});
} catch (Exception er) {
}
}
}).start();
}
dialog.dismiss();
}
return true;
}
});
GradientDrawable bg=new GradientDrawable();
bg.setColor(Color.WHITE);
bg.setCornerRadius(20);
dialog.getWindow().setBackgroundDrawable(bg);
}
});
}
void extractFile(ZipInputStream zis, String path) throws Exception {
BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream(path));
byte[] buf=new byte[1024];int len;
while ((len=zis.read(buf))!=-1) bos.write(buf,0,len);
bos.close();
}
void decompressFile(String zipPath) throws Exception {
File zip=new File(zipPath);
String dir=zip.getParent();
FileInputStream fis=new FileInputStream(zip);
ZipInputStream zis=new ZipInputStream(fis);
ZipEntry entry;
while ((entry=zis.getNextEntry())!=null) {
String full=dir+File.separator+entry.getName();
if(entry.isDirectory()) new File(full).mkdir();
else extractFile(zis,full);
zis.closeEntry();
}
zis.close();fis.close();
}
void onLoad() {
new Thread(new Runnable() {
public void run() {
try {
String jsonStr=httpGet(sec(upd));
if(jsonStr==null||jsonStr.trim().isEmpty()){
return;
}
JSONObject json=new JSONObject(jsonStr);
String remoteVer=json.getString("bb");
String log=json.getString("nr");
String dlUrl=json.getString("url");
String local=getPropValue("version");
if (!local.isEmpty()&&!local.equals(remoteVer)) {
Activity act=getActivity();
if(act!=null) act.runOnUiThread(new Runnable(){
public void run(){
k(log,dlUrl,remoteVer);
}
});
}
} catch (Exception e) {
}
}
}).start();
}